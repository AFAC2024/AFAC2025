import os
import time
import yaml
import openai
from pocketflow import Node, Flow
from dotenv import load_dotenv
from pathlib import Path
from datetime import datetime
import logging
import argparse
import shutil

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s - %(name)s] - %(levelname)s - %(message)s"
    )

_logger = logging.getLogger(__name__)

def get_time():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

from .utils.search_engine import search_web
from .utils.md2docx import convert_md_to_docx_with_mermaid
from .prompts import (
    DECISION_PROMPT,
    GENERATE_PROMPT
)
SAVE_ENCODING = "utf-8"

# 加载环境变量
load_dotenv()

# 从环境变量中初始化 OpenAI API 密钥
openai.api_key = os.getenv("OPENAI_API_KEY")
openai.api_base = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")


def strip_code_block(content:str, start_marker:str, end_marker:str):
    start_idx = content.find(start_marker)
    end_idx = content.rfind(end_marker)

    start_pos = start_idx + len(start_marker)
    end_pos = end_idx
    if start_pos == -1 or end_pos == -1 or start_pos >= end_pos:
        return content
    
    return content[start_pos:end_pos]

def call_llm(prompt: str) -> str:
    _logger.info(f"=> call_llm prompt: \n{prompt}")
    response = openai.chat.completions.create(
        model=os.getenv("OPENAI_MODEL", "gpt-4"),
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )
    resp_content = response.choices[0].message.content
    _logger.info(f"=> call_llm raw_response: \n{resp_content}")
    yaml_str = strip_code_block(resp_content, "```yaml", "```").strip()
    result = yaml.safe_load(yaml_str)

    _logger.info(f"=> call_llm parsed_response: \n{yaml.dump(result, allow_unicode=True)}")
    return result


class MainDecision(Node):  # 研报生成的决策节点
    def prep(self, shared):
        _logger.info(f"=> 进入节点: MainDecision")
        memory = shared["memory"]
        memory_str = yaml.dump(memory, allow_unicode=True)
        industry = shared["industry"]  # 行业名称
        max_decide = shared["max_decide"]
        decide_cnt = shared["decide_cnt"]
        return (
            memory_str,
            industry,
            max_decide,
            decide_cnt
        )
    
    def exec(self, prep_res):
        (
            memory_str,
            industry,
            max_decide,
            decide_cnt
        ) = prep_res

        _logger.info(f"\n=> decide_cnt: {decide_cnt}, max_decide: {max_decide}")
        prompt = DECISION_PROMPT.format(
            industry=industry,
            max_decide=max_decide,
            decide_cnt=decide_cnt,
            memory=memory_str,
        )
        resp = call_llm(prompt)
        
        # 打印决策结果        
        _logger.info(f"\n=> IndustryResearchFlow: done")
        return resp

    def post(self, shared, prep_res, exec_res):
        shared["decide_cnt"] += 1

        action = exec_res.get("action")
        if action == "search":
            shared["search_details"] = exec_res.get("search_details", "")
            _logger.info("=> 决策：执行 search")
        elif action == "generate":
            shared["generate_details"] = exec_res.get("generate_details", "")
            _logger.info("=> 决策：执行 generate")
        elif action == "complete":
            _logger.info("=> 决策：执行 complete")
        
        _logger.info(f"=> 退出节点: MainDecision, return: {action}")
        return action

class SearchInfo(Node):  # 信息搜索节点
    def prep(self, shared):
        _logger.info(f"=> 进入节点: SearchInfo")
        return [
            shared.get("search_details", []), 
            shared.get("search_log_dir", "./search_results")
        ]
    
    def exec(self, prep_res):
        all_results = []
        search_terms, search_log_dir = prep_res
        total = len(search_terms)
        for i, term in enumerate(search_terms, 1):
            _logger.info(f"=> 搜索关键词 ({i}/{total}): {term}")
            results = search_web(
                keywords=term, 
                max_results=10, 
                log_dir=search_log_dir
            )
            _logger.info(f"=> 找到 {len(list(results))} 条相关信息")
            all_results.append({"term": term, "results": results})
            time.sleep(15)  # 避免请求过快
        return all_results

    def post(self, shared, prep_res, exec_res):
        shared["memory"]["search_content"] += exec_res

        _logger.info(f"=> 退出节点: SearchInfo, return: search_done")
        return "search_done"

class GenerateSection(Node):  # 章节生成节点
    def prep(self, shared):
        _logger.info(f"=> 进入节点: GenerateSection")
        gen_log_dir = shared.get("generate_log_dir", "./generate_results")
        gen_log_dir = Path(gen_log_dir)
        gen_log_dir.mkdir(exist_ok=True)
        memory_str = yaml.dump(shared["memory"], allow_unicode=True)
        return (
            shared["industry"],
            shared["generate_details"],
            memory_str,
            gen_log_dir
        )

    def exec(self, prep_res):
        industry, generate_details, memory_str, gen_log_dir = prep_res
        _logger.info(f"=> 开始生成 {generate_details['name']} 章节...")
        prompt = GENERATE_PROMPT.format(
            industry=industry,
            section_name=generate_details["name"],
            section_focus=generate_details["focus"],
            memory=memory_str,
        )
        section = call_llm(prompt)
        _logger.info(f"章节 {section['index']}: {section['name']} 生成完成!")
        _logger.info(f"内容长度: {len(section['content'])} 字符")
        _logger.info(f"内容摘要: {section['abstract']}")

        save_path = str(gen_log_dir/ f"{get_time()}.md")
        with open(save_path, "w", encoding=SAVE_ENCODING) as fp:
            fp.write(section['content'])
        _logger.info(f"内容保存至: {save_path}")
        section["save_path"] = save_path
        return section
        

    def post(self, shared, prep_res, exec_res):
        section = exec_res
        section_abs = {
            "index": section["index"],
            "name": section["name"],
            "abstract": section["abstract"],
            "save_path": section["save_path"],
        }
        # 将已有章节加入记忆库
        shared["memory"]["generated_sections"].append(section_abs)

        _logger.info(f"=> 退出节点: GenerateSection, return: generate_done")
        return "generate_done"

class CompleteReport(Node):  # 研报完成节点
    def prep(self, shared):
        _logger.info(f"=> 进入节点: CompleteReport")
        return (
            shared["industry"],
            shared["memory"]["generated_sections"]
        )

    def exec(self, prep_res):
        industry, sections = prep_res
        # 整合所有章节内容
        content = f"# {industry}行业研究报告\n\n"
        for section in sections:
            _logger.info(f"=> 添加章节: {section['name']}")
            with open(section["save_path"], "r", encoding=SAVE_ENCODING) as fp:
                section_content = fp.read()
            content += f"\n## {section['index']} {section['name']}\n\n{section_content}\n"
        return content

    def post(self, shared, prep_res, exec_res):
        shared["report"] = exec_res
        _logger.info(f"=> 退出节点: CompleteReport, return: <完整报告内容>(len={len(shared['report'])})")
        return shared["report"]
    

def main(industry_name, time_range=None, output_dir="outputs"):
    """
    主函数：生成行业研究报告
    
    Args:
        industry_name (str): 行业名称
        time_range (str, optional): 时间范围，默认为None
        output_dir (str, optional): 输出目录，默认为"outputs"
    
    Returns:
        str: 生成的报告路径
    """
    _logger.info("=> start")
    _logger.info(f"=> 参数: industry_name = {industry_name}")
    _logger.info(f"=> 参数: time_range = {time_range}")
    _logger.info(f"=> 参数: output_dir = {output_dir}")
    
    # 初始化全局信息
    output_dir = Path(output_dir) / f"run_{get_time()}"
    output_dir.mkdir(exist_ok=True, parents=True)

    # 如果提供了时间范围，将其包含在行业名称中
    if time_range:
        industry_full_name = f"{industry_name}({time_range})"
    else:
        industry_full_name = industry_name

    shared_state = {
        "industry": industry_full_name,
        "max_decide": 10,
        "decide_cnt": 0,
        "search_log_dir": output_dir / "01_search_results",
        "generate_log_dir": output_dir / "02_generate_results",
        "memory": {
            "search_content": [],
            "generated_sections": [],
        },
    }

    # 构建工作流
    decision = MainDecision()
    search = SearchInfo()
    generate = GenerateSection()
    complete = CompleteReport()
    
    # 设置转换关系
    # 决策节点分发需求
    decision - "search" >> search
    decision - "generate" >> generate
    decision - "complete" >> complete
    # 返回决策节点
    search - "search_done" >> decision
    generate - "generate_done" >> decision
    
    # 运行工作流
    flow = Flow(start=decision)
    result = flow.run(shared_state)
    
    # 保存结果
    final_report_path = None
    if result:
        save_path = output_dir / f"{get_time()}_行业研报.md"
        with open(save_path, "w", encoding=SAVE_ENCODING) as fp:
            fp.write(result)
        _logger.info(f"=> markdown结果保存至: {save_path}")

        convert_path = save_path.parent / f"{save_path.stem}.docx"
        convert_md_to_docx_with_mermaid(
            input_md=save_path,
            output_docx=convert_path,
            tmp_dir_parent=output_dir,
        )
        _logger.info(f"=> docx结果保存至: {convert_path}")

        copy_path = Path.cwd() / f"{industry_full_name}_行业研报.docx"
        shutil.copy2(convert_path, copy_path)
        _logger.info(f"=> 最终结果保存至: {copy_path}")
        final_report_path = str(copy_path)
    else:
        _logger.error(f"=> 未生成研报，请检查错误。")

    _logger.info("=> 全部执行完毕")
    return final_report_path


"""
示例用法
nohup python run_industry_research_report.py \
-i 中国智能服务机器人产业 \
> _log/20250723_1651_main_v3.log 2>&1 &
"""
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='本程序将在在当前文件夹输出行业调查研报。')
    parser.add_argument("--industry_name", "-i", help='行业名称')
    parser.add_argument("--output_dir", "-o", help='生成研报时的临时文件夹', default="outputs")
    args = parser.parse_args() 

    # 调用main函数
    main(args.industry_name, output_dir=args.output_dir)


    