"""
整合的金融研报生成器
包含数据采集、分析和深度研报生成的完整流程
- 第一阶段：数据采集与基础分析
- 第二阶段：深度研报生成与格式化输出
"""

import os
import glob
import random
import time
import json
import uuid

import yaml
import re
import shutil
import requests
from datetime import datetime
from dotenv import load_dotenv
import importlib
from urllib.parse import urlparse

from company.data_analysis_agent import quick_analysis
from company.data_analysis_agent.config.llm_config import LLMConfig
from company.data_analysis_agent.utils.llm_helper import LLMHelper
from company.utils.get_shareholder_info import get_shareholder_info, get_table_content
from company.utils.get_financial_statements import get_all_financial_statements, save_financial_statements_to_csv
from company.utils.identify_competitors import identify_competitors_with_ai
from company.utils.get_stock_intro import get_stock_intro, save_stock_intro_to_txt
from company.utils.search_engine import SearchEngine


class IntegratedResearchReportGenerator:
    """整合的研报生成器类"""

    def __init__(self, target_company="商汤科技", target_company_code="00020", target_company_market="HK",
                 search_engine="ddg"):
        # 环境变量与全局配置
        load_dotenv()
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        self.model = os.getenv("OPENAI_MODEL", "gpt-4")
        # 打印模型
        print(f"🔧 使用的模型: {self.model}")
        self.target_company = target_company
        self.target_company_code = target_company_code
        self.target_company_market = target_company_market

        # 搜索引擎配置
        self.search_engine = SearchEngine(search_engine)
        print(f"🔍 搜索引擎已配置为: {search_engine.upper()}")

        # 目录配置
        self.data_dir = "./company/download_financial_statement_files"
        self.company_info_dir = "./company/company_info"
        self.industry_info_dir = "./company/industry_info"
        self.output_dir = "./company"

        # 创建必要的目录
        for dir_path in [self.data_dir, self.company_info_dir, self.industry_info_dir]:
            os.makedirs(dir_path, exist_ok=True)

        # LLM配置
        self.llm_config = LLMConfig(
            api_key=self.api_key,
            base_url=self.base_url,
            model=self.model,
            temperature=0.7,
            max_tokens=16384,
        )
        self.llm = LLMHelper(self.llm_config)

        # 存储分析结果
        self.analysis_results = {}
        self.supervisor_log = []

    def stage1_data_collection(self):
        """第一阶段：数据采集与基础分析"""
        print("\n" + "=" * 80)
        print("🚀 开始第一阶段：数据采集与基础分析")
        print("=" * 80)

        # 1. 获取竞争对手列表
        print("🔍 识别竞争对手...")
        other_companies = identify_competitors_with_ai(
            api_key=self.api_key,
            base_url=self.base_url,
            model_name=self.model,
            company_name=self.target_company
        )
        listed_companies = [company for company in other_companies if company.get('market') != "未上市"]

        # 2. 获取目标公司财务数据
        print(f"\n📊 获取目标公司 {self.target_company} 的财务数据...")
        target_financials = get_all_financial_statements(
            stock_code=self.target_company_code,
            market=self.target_company_market,
            period="年度",
            verbose=False
        )
        save_financial_statements_to_csv(
            financial_statements=target_financials,
            stock_code=self.target_company_code,
            market=self.target_company_market,
            company_name=self.target_company,
            period="年度",
            save_dir=self.data_dir
        )

        # 3. 获取竞争对手的财务数据
        print("\n📊 获取竞争对手的财务数据...")
        competitors_financials = {}
        for company in listed_companies:
            company_name = company.get('name')
            company_code = company.get('code')
            market_str = company.get('market', '')

            if "A" in market_str:
                market = "A"
                if not (company_code.startswith('SH') or company_code.startswith('SZ')):
                    if company_code.startswith('6'):
                        company_code = f"SH{company_code}"
                    else:
                        company_code = f"SZ{company_code}"
            elif "港" in market_str:
                market = "HK"

            print(f"  获取 {company_name}({market}:{company_code}) 的财务数据")
            try:
                company_financials = get_all_financial_statements(
                    stock_code=company_code,
                    market=market,
                    period="年度",
                    verbose=False
                )
                save_financial_statements_to_csv(
                    financial_statements=company_financials,
                    stock_code=company_code,
                    market=market,
                    company_name=company_name,
                    period="年度",
                    save_dir=self.data_dir
                )
                competitors_financials[company_name] = company_financials
                time.sleep(2)
            except Exception as e:
                print(f"  获取 {company_name} 财务数据失败: {e}")

        # 4. 获取公司基础信息
        print("\n🏢 获取公司基础信息...")
        all_base_info_targets = [(self.target_company, self.target_company_code, self.target_company_market)]

        for company in listed_companies:
            company_name = company.get('name')
            company_code = company.get('code')
            market_str = company.get('market', '')
            if "A" in market_str:
                market = "A"
                if not (company_code.startswith('SH') or company_code.startswith('SZ')):
                    if company_code.startswith('6'):
                        company_code = f"SH{company_code}"
                    else:
                        company_code = f"SZ{company_code}"
            elif "港" in market_str:
                market = "HK"
            all_base_info_targets.append((company_name, company_code, market))

        # 添加特定公司如百度
        all_base_info_targets.append(("百度", "09888", "HK"))

        for company_name, company_code, market in all_base_info_targets:
            print(f"  获取 {company_name}({market}:{company_code}) 的基础信息")
            company_info = get_stock_intro(company_code, market=market)
            if company_info:
                save_path = os.path.join(self.company_info_dir, f"{company_name}_{market}_{company_code}_info.txt")
                save_stock_intro_to_txt(company_code, market, save_path)
                print(f"    信息已保存到: {save_path}")
            else:
                print(f"    未能获取到 {company_name} 的基础信息")
            time.sleep(1)

        # 5. 搜索行业信息
        print("\n🔍 搜索行业信息...")
        all_search_results = {}
        # 搜索目标公司行业信息
        target_search_keywords = f"{self.target_company} 行业地位 市场份额 竞争分析 业务模式"
        print(f"  正在搜索: {target_search_keywords}")
        # 进行目标公司搜索
        target_results = self.search_engine.search(target_search_keywords, 10)
        all_search_results[self.target_company] = target_results

        # 搜索竞争对手行业信息
        for company in listed_companies:
            company_name = company.get('name')
            search_keywords = f"{company_name} 行业地位 市场份额 业务模式 发展战略"
            print(f"  正在搜索: {search_keywords}")
            competitor_results = self.search_engine.search(search_keywords, 10)
            all_search_results[company_name] = competitor_results
            # 增加延迟避免请求过于频繁
            time.sleep(random.uniform(*self.search_engine.delay))

        # 保存搜索结果
        search_results_file = os.path.join(self.industry_info_dir, "all_search_results.json")
        with open(search_results_file, 'w', encoding='utf-8') as f:
            json.dump(all_search_results, f, ensure_ascii=False, indent=2)

        # 6. 运行财务分析
        print("\n📈 运行财务分析...")

        # 单公司分析
        results = self.analyze_companies_in_directory(self.data_dir, self.llm_config)

        # 两两对比分析
        comparison_results = self.run_comparison_analysis(
            self.data_dir, self.target_company, self.llm_config
        )

        # 合并所有报告
        merged_results = self.merge_reports(results, comparison_results)

        # 商汤科技估值与预测分析
        sensetime_files = self.get_sensetime_files(self.data_dir)
        sensetime_valuation_report = None
        if sensetime_files:
            sensetime_valuation_report = self.analyze_sensetime_valuation(sensetime_files, self.llm_config)

        # 7. 整理所有分析结果
        print("\n📋 整理分析结果...")

        # 整理公司信息
        company_infos = self.get_company_infos(self.company_info_dir)
        company_infos = self.llm.call(
            f"请整理以下公司信息内容，确保格式清晰易读，并保留关键信息：\n{company_infos}",
            system_prompt="你是一个专业的公司信息整理师。",
            max_tokens=16384,
            temperature=0.5
        )

        # 整理股权信息
        info = get_shareholder_info()
        shangtang_shareholder_info = info.get("tables")
        table_content = get_table_content(shangtang_shareholder_info)
        shareholder_analysis = self.llm.call(
            "请分析以下股东信息表格内容：\n" + table_content,
            system_prompt="你是一个专业的股东信息分析师。",
            max_tokens=16384,
            temperature=0.5
        )

        # 整理行业信息搜索结果
        with open(search_results_file, 'r', encoding='utf-8') as f:
            all_search_results = json.load(f)
        search_res = ""
        for company, results in all_search_results.items():
            search_res += f"【{company}搜索信息开始】\n"
            for result in results:
                search_res += f"标题: {result.get('title', '无标题')}\n"
                search_res += f"链接: {result.get('url', '无链接')}\n"
                search_res += f"摘要: {result.get('description', '无摘要')}\n"
                search_res += "----\n"
            search_res += f"【{company}搜索信息结束】\n\n"

        # 保存阶段一结果
        formatted_report = self.format_final_reports(merged_results)

        # 统一保存为markdown
        md_output_file = os.path.join(self.output_dir, f"财务研报汇总_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md")
        with open(md_output_file, 'w', encoding='utf-8') as f:
            f.write(f"# 公司基础信息\n\n## 整理后公司信息\n\n{company_infos}\n\n")
            f.write(f"# 股权信息分析\n\n{shareholder_analysis}\n\n")
            f.write(f"# 行业信息搜索结果\n\n{search_res}\n\n")
            f.write(f"# 财务数据分析与两两对比\n\n{formatted_report}\n\n")
            if sensetime_valuation_report and isinstance(sensetime_valuation_report, dict):
                f.write(
                    f"# 商汤科技估值与预测分析\n\n{sensetime_valuation_report.get('final_report', '未生成报告')}\n\n")

        print(f"\n✅ 第一阶段完成！基础分析报告已保存到: {md_output_file}")

        # 存储结果供第二阶段使用
        self.analysis_results = {
            'md_file': md_output_file,
            'company_infos': company_infos,
            'shareholder_analysis': shareholder_analysis,
            'search_res': search_res,
            'formatted_report': formatted_report,
            'sensetime_valuation_report': sensetime_valuation_report
        }

        return md_output_file

    def stage2_initial_report_generation(self, md_file_path):
        """第二阶段：深度研报生成"""
        print("\n" + "=" * 80)
        print("🚀 开始第二阶段：深度研报生成")
        print("=" * 80)

        # 处理图片路径
        print("🖼️ 处理图片路径...")
        new_md_path = md_file_path.replace('.md', '_images.md')
        images_dir = os.path.join(os.path.dirname(md_file_path), 'images')
        self.extract_images_from_markdown(md_file_path, images_dir, new_md_path)

        # 加载报告内容
        report_content = self.load_report_content(new_md_path)
        background = self.get_background()

        # 生成大纲
        print("\n📋 生成报告大纲...")
        parts = self.generate_outline(self.llm, background, report_content)

        # 分段生成深度研报
        print("\n✍️ 开始分段生成深度研报...")
        full_report = ['# 商汤科技公司研报\n']
        prev_content = ''

        for idx, part in enumerate(parts):
            part_title = part.get('part_title', f'部分{idx + 1}')
            print(f"\n  正在生成：{part_title}")
            is_last = (idx == len(parts) - 1)
            section_text = self.generate_section(
                self.llm, part_title, prev_content, background, report_content, is_last
            )
            full_report.append(section_text)
            print(f"  ✅ 已完成：{part_title}")
            prev_content = '\n'.join(full_report)

        # 5. 保存初稿
        final_report_text = '\n\n'.join(full_report)
        initial_draft_path = os.path.join(self.output_dir,
                                          f"深度研报初稿_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md")
        self.save_markdown(final_report_text, initial_draft_path)

        print(f"\n✅ 第二阶段完成！深度研报初稿已保存到: {initial_draft_path}")
        return initial_draft_path

    def stage3_supervisor_refinement(self, initial_draft_path, max_iterations=3):
        """第三阶段：监督Agent迭代优化"""
        print("\n" + "=" * 80)
        print("🚀 开始第三阶段：监督 Agent 迭代优化")
        print("=" * 80)

        # 1. 预渲染并验证Mermaid图表
        print("📊 预渲染并验证 Mermaid 图表...")
        current_content = self.load_report_content(initial_draft_path)

        # 2. 开始迭代优化循环
        for i in range(max_iterations + 1):
            print(f"\n--- 优化迭代: {i + 1}/{max_iterations} ---")

            # 2.1 Supervisor Agent 制定计划
            print("🤔 Supervisor Agent 正在审查报告并制定计划...")
            plan = self._get_supervisor_plan(current_content, i + 1, max_iterations)

            if not plan:
                print("✅ Supervisor Agent 认为报告质量已达标，或未生成有效计划，提前结束优化。")
                break

            print(f"📝 Supervisor Agent 生成了 {len(plan)} 个任务计划。")

            # 2.2 执行计划
            for task_idx, task in enumerate(plan):
                print(f"\n  执行任务 {task_idx + 1}/{len(plan)}: 调用工具 `{task.get('tool')}`")
                tool_name = task.get("tool")
                params = task.get("params", {})

                result_log = f"**任务 {i + 1}-{task_idx + 1}**: 调用 `{tool_name}`\n" \
                             f"**参数**: {json.dumps(params, ensure_ascii=False, indent=2)}\n"

                try:
                    if tool_name == "background_searcher":
                        research_result = self._tool_background_searcher(**params)
                        result_log += f"**结果**: [此工具的结果需要由 writer_editor 整合]\n{research_result}\n"
                        print("    - 背景搜索完成，结果将由 writer_editor 整合。")

                    elif tool_name == "data_analyzer":
                        analysis_result = self._tool_data_analyzer(**params)
                        result_log += f"**结果**: [此工具的结果需要由 writer_editor 整合]\n{analysis_result}\n"
                        print("    - 数据分析完成，结果将由 writer_editor 整合。")

                    elif tool_name == "writer_editor":
                        current_content = self._tool_writer_editor(current_content, **params)
                        result_log += "**结果**: 报告内容已更新。\n"
                        print("    - 报告内容已根据计划修改。")

                    else:
                        result_log += "**结果**: 未知工具，已跳过。\n"
                        print(f"    - [警告] 未知工具: {tool_name}")

                except Exception as e:
                    error_msg = f"    - [错误] 执行工具 `{tool_name}` 时出错: {e}"
                    print(error_msg)
                    result_log += f"**错误**: {error_msg}\n"

                self.supervisor_log.append(result_log)

        # 3. 最终清理和保存
        print("\n✨ 优化流程结束...")
        final_report_path = initial_draft_path.replace("初稿", "").replace(".md", "_final.md")
        self.save_markdown(current_content, final_report_path)

        print(f"\n✅ 第三阶段完成！最终优化版研报已保存到: {final_report_path}")
        return final_report_path

    def run_full_pipeline(self):
        """运行完整流程"""
        print("\n" + "=" * 100)
        print("🎯 启动整合的金融研报生成器 V2.1 流程")
        print("=" * 100)

        # 第一阶段：数据采集与基础分析
        base_report_md = self.stage1_data_collection()

        # 第二阶段：初始深度研报生成
        initial_draft_md = self.stage2_initial_report_generation(base_report_md)

        # 第三阶段：监督 Agent 迭代优化
        final_report_md = self.stage3_supervisor_refinement(initial_draft_md)

        # 最终格式化与转换
        print("\n🎨 格式化并转换为最终文档...")
        self.format_markdown(final_report_md)

        original_md_path = os.path.abspath(final_report_md)
        original_images_dir = os.path.join(os.path.dirname(original_md_path), 'images')

        # 获取项目根目录
        root_dir = os.getcwd()

        # 定义文件/目录在根目录下的临时副本路径
        md_basename = os.path.basename(original_md_path)
        root_md_path_copy = os.path.join(root_dir, md_basename)
        root_images_dir_copy = os.path.join(root_dir, 'images')

        # 预先定义最终的 DOCX 文件路径，它将在根目录下生成
        final_report_docx = root_md_path_copy.replace('.md', '.docx')
        generated_docx_path = None  # 用于存储函数返回值

        # 使用 try...finally 确保临时副本总能被清理
        try:
            # 2. 将 MD 文件和 images 目录复制到根目录
            print(f"\n[工作区准备] 正在将文件复制到根目录以进行 DOCX 转换...")
            if os.path.exists(original_md_path):
                # 使用 shutil.copy2 来复制文件，它会保留元数据
                shutil.copy2(original_md_path, root_md_path_copy)
                print(f"  - 已复制: {original_md_path} -> {root_md_path_copy}")

            # 只有当原始 images 目录存在时才复制它
            if os.path.exists(original_images_dir):
                # 使用 shutil.copytree 来递归复制整个目录
                shutil.copytree(original_images_dir, root_images_dir_copy)
                print(f"  - 已复制: {original_images_dir} -> {root_images_dir_copy}")
            else:
                print(f"  - [信息] 未找到 images 目录，跳过复制。")

            # 3. 在根目录下调用 "库函数" 进行转换
            # 函数的输入是位于根目录的 MD 文件副本路径
            generated_docx_path = self.convert_to_docx(root_md_path_copy)

        finally:
            # 4. 无论成功与否，都删除根目录下的临时副本
            print(f"\n[工作区清理] 正在删除根目录下的临时副本...")
            if os.path.exists(root_md_path_copy):
                os.remove(root_md_path_copy)
                print(f"  - 已删除副本: {root_md_path_copy}")

            if os.path.exists(root_images_dir_copy):
                # 使用 shutil.rmtree 来递归删除整个目录
                shutil.rmtree(root_images_dir_copy)
                print(f"  - 已删除副本: {root_images_dir_copy}")

        # 如果转换失败，generated_docx_path 将是 None
        if not generated_docx_path or not os.path.exists(generated_docx_path):
            print("[警告] DOCX 文件生成失败，路径将返回 None。")
            final_report_docx = None  # 确保返回 None

        print("\n" + "=" * 100)
        print("🎉 完整流程执行完毕！")
        print(f"📊 基础分析报告: {base_report_md}")
        print(f"📋 最终优化研报 (Markdown): {final_report_md}")  # 这是它在原始位置的路径
        print(f"📄 最终优化研报 (Word): {final_report_docx}")  # 这是它在根目录的路径
        print("=" * 100)

        # 返回原始MD路径和在根目录生成的DOCX路径
        return final_report_docx

    # ========== 辅助方法（从原始脚本移植） ==========

    def get_company_infos(self, data_dir="./company_info"):
        """获取公司信息"""
        all_files = os.listdir(data_dir)
        company_infos = ""
        for file in all_files:
            if file.endswith(".txt"):
                company_name = file.split(".")[0]
                with open(os.path.join(data_dir, file), 'r', encoding='utf-8') as f:
                    content = f.read()
                company_infos += f"【公司信息开始】\n公司名称: {company_name}\n{content}\n【公司信息结束】\n\n"
        return company_infos

    def get_company_files(self, data_dir):
        """获取公司文件"""
        all_files = glob.glob(f"{data_dir}/*.csv")
        companies = {}
        for file in all_files:
            filename = os.path.basename(file)
            company_name = filename.split("_")[0]
            companies.setdefault(company_name, []).append(file)
        return companies

    def analyze_individual_company(self, company_name, files, llm_config, query=None, verbose=True):
        """分析单个公司"""
        if query is None:
            query = "基于表格的数据，分析有价值的内容，并绘制相关图表。最后生成汇报给我。"
        report = quick_analysis(
            query=query, files=files, llm_config=llm_config, output_dir="./company/outputs",
            absolute_path=True, max_rounds=20
        )
        return report

    def format_final_reports(self, all_reports):
        """格式化最终报告"""
        formatted_output = []
        for company_name, report in all_reports.items():
            formatted_output.append(f"【{company_name}财务数据分析结果开始】")
            final_report = report.get("final_report", "未生成报告")
            formatted_output.append(final_report)
            formatted_output.append(f"【{company_name}财务数据分析结果结束】")
            formatted_output.append("")
        return "\n".join(formatted_output)

    def analyze_companies_in_directory(self, data_directory, llm_config,
                                       query="基于表格的数据，分析有价值的内容，并绘制相关图表。最后生成汇报给我。"):
        """分析目录中的所有公司"""
        company_files = self.get_company_files(data_directory)
        all_reports = {}
        for company_name, files in company_files.items():
            report = self.analyze_individual_company(company_name, files, llm_config, query, verbose=False)
            if report:
                all_reports[company_name] = report
        return all_reports

    def compare_two_companies(self, company1_name, company1_files, company2_name, company2_files, llm_config):
        """比较两个公司"""
        query = "基于两个公司的表格的数据，分析有共同点的部分，绘制对比分析的表格，并绘制相关图表。最后生成汇报给我。"
        all_files = company1_files + company2_files
        report = quick_analysis(
            query=query,
            files=all_files,
            llm_config=llm_config,
            output_dir="./company/outputs",
            absolute_path=True,
            max_rounds=20
        )
        return report

    def run_comparison_analysis(self, data_directory, target_company_name, llm_config):
        """运行对比分析"""
        company_files = self.get_company_files(data_directory)
        if not company_files or target_company_name not in company_files:
            return {}
        competitors = [company for company in company_files.keys() if company != target_company_name]
        comparison_reports = {}
        for competitor in competitors:
            comparison_key = f"{target_company_name}_vs_{competitor}"
            report = self.compare_two_companies(
                target_company_name, company_files[target_company_name],
                competitor, company_files[competitor],
                llm_config
            )
            if report:
                comparison_reports[comparison_key] = {
                    'company1': target_company_name,
                    'company2': competitor,
                    'report': report
                }
        return comparison_reports

    def merge_reports(self, individual_reports, comparison_reports):
        """合并报告"""
        merged = {}
        for company, report in individual_reports.items():
            merged[company] = report
        for comp_key, comp_data in comparison_reports.items():
            merged[comp_key] = comp_data['report']
        return merged

    def get_sensetime_files(self, data_dir):
        """获取商汤科技的财务数据文件"""
        all_files = glob.glob(f"{data_dir}/*.csv")
        sensetime_files = []
        for file in all_files:
            filename = os.path.basename(file)
            company_name = filename.split("_")[0]
            if "商汤" in company_name or "SenseTime" in company_name:
                sensetime_files.append(file)
        return sensetime_files

    def analyze_sensetime_valuation(self, files, llm_config):
        """分析商汤科技的估值与预测"""
        query = "基于三大表的数据，构建估值与预测模型，模拟关键变量变化对财务结果的影响,并绘制相关图表。最后生成汇报给我。"
        report = quick_analysis(
            query=query, files=files, llm_config=llm_config, absolute_path=True, output_dir="./company/outputs",
            max_rounds=20
        )
        return report

    # ========== 深度研报生成相关方法 ==========

    def load_report_content(self, md_path):
        """加载报告内容"""
        with open(md_path, "r", encoding="utf-8") as f:
            return f.read()

    def get_background(self):
        """获取背景信息"""
        return '''
本报告基于自动化采集与分析流程，涵盖如下环节：
- 公司基础信息等数据均通过akshare、公开年报、主流财经数据源自动采集。
- 财务三大报表数据来源：东方财富-港股-财务报表-三大报表 (https://emweb.securities.eastmoney.com/PC_HKF10/FinancialAnalysis/index)
- 主营业务信息来源：同花顺-主营介绍 (https://basic.10jqka.com.cn/new/000066/operate.html)
- 股东结构信息来源：同花顺-股东信息 (https://basic.10jqka.com.cn/HK0020/holder.html) 通过网页爬虫技术自动采集
- 行业信息通过DuckDuckGo等公开搜索引擎自动抓取，引用了权威新闻、研报、公司公告等。
- 财务分析、对比分析、估值与预测均由大模型（如GPT-4）自动生成，结合了行业对标、财务比率、治理结构等多维度内容。
- 相关数据与分析均在脚本自动化流程下完成，确保数据来源可追溯、分析逻辑透明。
- 详细引用与外部链接已在正文中标注。
- 数据接口说明与免责声明见文末。
'''

    def generate_outline(self, llm, background, report_content):
        """生成大纲"""
        outline_prompt = f"""
你是一位顶级金融分析师和研报撰写专家。请基于以下背景和财务研报汇总内容，生成一份详尽的《{self.target_company}科技公司研报》分段大纲，要求：
- 以yaml格式输出，务必用```yaml和```包裹整个yaml内容，便于后续自动分割。
- 每一项为一个主要部分，每部分需包含：
  - part_title: 章节标题
  - part_desc: 本部分内容简介
- 章节需覆盖公司基本面、财务分析、行业对比、估值与预测、治理结构、投资建议、风险提示、数据来源等。
- 只输出yaml格式的分段大纲，不要输出正文内容。

【背景说明开始】
{background}
【背景说明结束】

【财务研报汇总内容开始】
{report_content}
【财务研报汇总内容结束】
"""
        outline_list = llm.call(
            outline_prompt,
            system_prompt="你是一位顶级金融分析师和研报撰写专家，善于结构化、分段规划输出，分段大纲必须用```yaml包裹，便于后续自动分割。",
            max_tokens=4096,
            temperature=0.3
        )
        print("\n===== 生成的分段大纲如下 =====\n")
        print(outline_list)
        try:
            if '```yaml' in outline_list:
                yaml_block = outline_list.split('```yaml')[1].split('```')[0]
            else:
                yaml_block = outline_list
            parts = yaml.safe_load(yaml_block)
            if isinstance(parts, dict):
                parts = list(parts.values())
        except Exception as e:
            print(f"[大纲yaml解析失败] {e}")
            parts = []
        return parts

    def generate_section(self, llm, part_title, prev_content, background, report_content, is_last):
        """生成章节"""
        section_prompt = f"""
你是一位顶级金融分析师和研报撰写专家。请基于以下内容，直接输出\"{part_title}\"这一部分的完整研报内容。

**重要要求：**
1. 直接输出完整可用的研报内容，以\"## {part_title}\"开头
2. 在正文中引用数据、事实、图片等信息时，适当位置插入参考资料符号（如[1][2][3]），符号需与文末引用文献编号一致
3. **图片引用要求（务必严格遵守）：**
   - 只允许引用【财务研报汇总内容】中真实存在的图片地址（格式如：./images/图片名字.png），必须与原文完全一致。
   - 禁止虚构、杜撰、改编、猜测图片地址，未在【财务研报汇总内容】中出现的图片一律不得引用。
   - 如需插入图片，必须先在【财务研报汇总内容】中查找，未找到则不插入图片，绝不编造图片。
   - 如引用了不存在的图片，将被判为错误输出。
4. 不要输出任何【xxx开始】【xxx结束】等分隔符
5. 不要输出\"建议补充\"、\"需要添加\"等提示性语言
6. 不要编造图片地址或数据
7. 内容要详实、专业，可直接使用
8. 内容要图文并茂，尽量**多引用可视化图表**。如果针对某部分数据不存在可视化图表，可以根据文字中的数据，使用mermaid代码块生成简单的图表。

**Mermaid图表生成指导：**
- 通用规则：优先使用 `pie` (饼图) 或 `graph` (流程图)。。
- 饼图 (`pie`) 语法：标签和数值用冒号 `:` 分隔。**数值部分必须是纯数字**，严禁包含百分号`%`、单位或任何非数字字符。Mermaid会自动计算百分比。

**数据来源标注：**
- 财务数据 标注：（数据来源：东方财富-港股-财务报表[1]）
- 主营业务信息 标注：（数据来源：同花顺-主营介绍[2]）
- 股东结构信息 标注：（数据来源：同花顺-股东信息网页爬虫[3]）
- 行业信息1 标注：（数据来源：公开搜索引擎搜索结果的url1[4]）
- 行业信息2 标注：（数据来源：公开搜索引擎搜索结果的url2[5]）
- **依此类推，尽量为每个信息找到合适的来源。对每个不重复的来源，顺次往下标序号**

【本次任务】
{part_title}

【已生成前文】
{prev_content}

【背景说明开始】
{background}
【背景说明结束】

【财务研报汇总内容开始】
{report_content}
【财务研报汇总内容结束】
"""
        if is_last:
            section_prompt += """
请在本节最后以"引用文献"格式，列出所有正文中用到的参考资料，格式如下：
[1] 东方财富-港股-财务报表: https://emweb.securities.eastmoney.com/PC_HKF10/FinancialAnalysis/index
[2] 同花顺-主营介绍: https://basic.10jqka.com.cn/new/000066/operate.html
[3] 同花顺-股东信息: https://basic.10jqka.com.cn/HK0020/holder.html
[4] ("行业信息搜索结果"中的)"标题": "链接"
[5] 以此类推
"""
        section_text = llm.call(
            section_prompt,
            system_prompt="你是顶级金融分析师，专门生成完整可用的研报内容。输出必须是完整的研报正文，无需用户修改。严格禁止输出分隔符、建议性语言或虚构内容。只允许引用真实存在于【财务研报汇总内容】中的图片地址，严禁虚构、猜测、改编图片路径。如引用了不存在的图片，将被判为错误输出。",
            max_tokens=16384,
            temperature=0.5
        )
        return section_text

    def _get_supervisor_plan(self, content, iteration, max_iterations):
        """调用LLM获取Supervisor的行动计划"""
        # 获取可用文件列表，以供prompt使用
        company_files_map = self.get_company_files(self.data_dir)
        available_files_str = json.dumps(company_files_map, ensure_ascii=False, indent=2)

        # 将Prompt定义在函数内部
        SUPERVISOR_AGENT_PROMPT = f"""
    你是研报审查与优化监督官 (Supervisor Agent)，负责审查一份自动生成的金融研报初稿，并制定一个详细的、分步的优化计划。

    **你的核心任务：**
    1.  **审查报告**：通读下方提供的研报全文，从结构、内容、数据、逻辑流畅性等多个维度进行评估。
    2.  **识别缺陷**：找出报告中的具体问题，例如内容缺失、分析肤浅、逻辑断裂、信息陈旧等。
    3.  **制定计划**：基于发现的缺陷，设计一个由多个具体任务组成的行动计划。**你不能直接修改报告**，而是通过调用三个专用工具来完成优化。

    ---
    **可用工具与数据源:**

    **1. `background_searcher`**:
       - **用途**: 当你需要补充宏观背景、市场数据、发展模式、技术趋势等**文字性资料**时调用。
       - **调用格式**: `{{"tool": "background_searcher", "params": {{"research_request": "你需要研究的具体问题"}}}}`

    **2. `data_analyzer`**:
       - **用途**: 当你需要基于**已有的公司财务报表**（三大表CSV文件）进行新的数据分析或可视化时调用。
       - **重要**: 此工具**只能**分析下方“可用财务数据文件”中列出的公司数据，无法获取其他任何数据。
       - **工作方式**: 你需要根据你的分析目标，从下面的文件列表中**选择**一个或多个相关的公司，并在`company_names`参数中提供它们的名字。
       - **可用财务数据文件**:
         ```json
         {available_files_str}
         ```
       - **调用格式**: `{{"tool": "data_analyzer", "params": {{"query": "需要分析的具体问题", "company_names": ["公司A", "公司B"]}}}}`

    **3. `writer_editor`**:
       - **用途**: 当你需要修改文本、或将前两个工具的分析结果整合进报告时调用。
       - **调用格式**: `{{"tool": "writer_editor", "params": {{"modifications": [{{...}}], "new_references": [{{...}}]}}}}`
         - `modifications`: 一个列表，每项包含`location`（用于定位原文）和`new_content`（新的段落内容）。
                            `location`包括`starts_with`和`ends_with`两个属性，分别指定起始位置的20个字符和结束位置的20个字符。最终我将替换从`start_with`到`ends_with`的文本为`new_content`。
         - `new_references`: 一个可选列表，用于添加新的参考文献，格式与研报内容最后的参考文献一致。

    ---
    **工作流程：**
    - 这是第 `{iteration}`/`{max_iterations}` 轮优化。
    - 查看下方的“历史行动日志”，了解之前已经完成了哪些优化。
    - 仔细阅读“当前研报内容”。
    - 制定本轮的行动计划。计划可以包含多个步骤（调用多个工具）。
    - **如果认为报告质量已足够好，或已无明显可修复的缺陷，请输出一个空列表 `[]` 来结束优化流程。达到max_iterations时强制进行这一步骤**

    ---
    **历史行动日志:**
    {str(self.supervisor_log)}

    ---
    **当前研报内容:**
    {content}

    ---
    请输出你本轮的行动计划。

    **输出格式 (严格遵守的JSON，一个包含任务对象的列表):**
    [
      {{
        "tool": "tool_name",
        "params": {{...}}
      }}
    ]
    """

        response = self.llm.call(
            SUPERVISOR_AGENT_PROMPT,
            system_prompt="你是一个顶级的金融研报审查监督官，输出必须是严格的JSON格式行动计划。",
            temperature=0.2
        )

        plan = self.parse_llm_json_output(response)

        # 确保plan是一个列表，以防解析器返回了别的类型
        if not isinstance(plan, list):
            print(f"🚨 解析结果不是一个列表，而是一个 {type(plan)}。将使用空计划。")
            return []

        return plan

    def _tool_background_searcher(self, research_request: str, max_loops=8):
        """工具1: 背景知识搜查官"""
        print(f"    -> [工具] 背景搜查官启动，研究问题: '{research_request[:50]}...'")

        agent_log = []
        search_results_summary = {}

        # 将Prompt定义在函数内部
        DATA_COLLECTOR_PROMPT = """
        你是数据搜集官，一个顶级的信息研究专家。你的任务是接收一个研究问题，通过迭代式的“规划-搜索-评估”循环，最终提供一份全面、客观、带引用的结构化答案。
        你的思考框架 (Chain-of-Thought):
        评估任务: 我是否已经有了足够的信息来回答最初的研究问题？
        如果已有搜索结果: 分析这些结果，判断是否覆盖了问题的所有方面。如果还有未解的子问题，或信息不够深入，我需要规划新一轮的搜索。
        如果是新任务: 我需要将这个复杂问题拆解成一系列具体的、可搜索的子问题/关键词。
        制定行动计划:
        如果需要继续搜索 (Action: continue_search): 我将生成新的、更精确的搜索关键词，以填补信息空白。
        如果信息已足够 (Action: synthesize_and_finalize): 我将开始整合所有搜集到的信息，形成最终的、带引用的答案。
        执行行动: 根据计划，生成一个包含明确action和相应参数的JSON。
        当前总研究目标:
        {main_research_request}
        本Agent的历史行动日志（多于5次未搜索到时不再继续搜索，回答没有非常相关结果，给出一些较相关背景就行）:
        {agent_log}
        当前已搜集到的信息摘要 (关键词 -> 搜索结果):
        {search_results_summary}
        请根据当前状态，决定你的下一步行动。
        输出格式 (严格遵守的JSON):
        {{
        "reasoning": "string (你的思考过程)",
        "action": "string (从 'continue_search', 'synthesize_and_finalize' 中选择)",
        "action_params": {{
        "new_keywords": ["string (当action='continue_search'时)"],
        "final_answer": "string (当action='synthesize_and_finalize'时，分点式的、带引用标记([1],[2],...)的详细回答文本)",
        "references": {{
        "1": {{ "title": "string", "url": "string" }}
        }} (当action='synthesize_and_finalize'时)
        }},
        "my_action_summary": "string (对你本次行动的简短总结)"
        }}
        """
        for i in range(max_loops):
            prompt = DATA_COLLECTOR_PROMPT.format(
                main_research_request=research_request,
                agent_log="\n".join(agent_log) if agent_log else "无",
                search_results_summary=json.dumps(search_results_summary, ensure_ascii=False, indent=2)
            )
            response_str = self.llm.call(prompt, system_prompt="你是一个顶级的信息研究专家，严格输出JSON。")

            try:
                response_json = self.parse_llm_json_output(response_str)
                action = response_json.get("action")
                action_params = response_json.get("action_params", {})
                agent_log.append(f"第{i + 1}轮: {response_json.get('my_action_summary', '无总结')}")

                if action == "continue_search":
                    keywords = action_params.get("new_keywords", [])
                    if not keywords: return "背景搜查官未能生成新的搜索关键词，任务中止。"
                    print(f"      - 第{i + 1}轮搜索，关键词: {keywords}")
                    for kw in keywords:
                        results = self.search_engine.search(kw, 10)
                        search_results_summary[kw] = results
                        time.sleep(1)

                elif action == "synthesize_and_finalize":
                    print("      - 信息搜集完毕，正在整合答案。")
                    final_answer = action_params.get("final_answer", "未能生成最终答案。")
                    references = action_params.get("references", {})

                    # 格式化输出，以便writer_editor使用
                    ref_text = "\n\n**引用来源:**\n"
                    for ref_id, ref_data in references.items():
                        ref_text += f"[{ref_id}] {ref_data.get('title')}: {ref_data.get('url')}\n"

                    return final_answer + ref_text

            except Exception as e:
                print(f"      - [错误] 背景搜查官执行出错: {e}")
                return f"背景搜查官在执行中遇到错误: {e}"

        return "经过多轮搜索，未能得出结论性答案。请检查研究问题或关键词。"

    def _tool_data_analyzer(self, query: str, company_names: list):
        """工具2: 数据分析与可视化 (V2.2 - 采用您提供的稳健图片处理逻辑)"""
        print(f"    -> [工具] 数据分析官启动，分析任务: '{query[:50]}...'")

        # 1. 查找相关公司的CSV文件
        company_files_map = self.get_company_files(self.data_dir)
        files_to_analyze = []
        for name in company_names:
            if name in company_files_map:
                files_to_analyze.extend(company_files_map[name])
            else:
                print(f"      - [警告] Supervisor请求分析的公司 '{name}' 未找到财务数据文件。")

        if not files_to_analyze:
            return "数据分析失败：未找到任何相关公司的财务数据文件。"

        # 2. 调用 quick_analysis
        # 其输出目录应在 'company' 模块内部，以保持模块化
        company_tool_outputs_dir = os.path.join(self.output_dir, "outputs")
        report_data = quick_analysis(
            query=query,
            files=files_to_analyze,
            llm_config=self.llm_config,
            output_dir=company_tool_outputs_dir,
            absolute_path=True,
            max_rounds=20
        )

        if not report_data or "final_report" not in report_data:
            return "数据分析未能生成报告。"

        # 3. 提取、复制图片并更新路径 (采用新的稳健逻辑)
        content = report_data["final_report"]
        pattern = re.compile(r'!\[[^\]]*\]\(([^)]+)\)')

        replace_map = {}
        not_exist_set = set()

        # 第一步: 遍历所有找到的图片路径，检查并准备替换
        for img_path_raw in pattern.findall(content):
            img_path = img_path_raw.strip()

            # 由于 quick_analysis 返回的是绝对路径，我们直接检查其是否存在
            if os.path.exists(img_path):
                filename = os.path.basename(img_path)
                new_filename = f"{filename}"
                dst_path = os.path.join(self.output_dir, "images", new_filename)

                try:
                    # 复制图片到统一的 images 目录
                    shutil.copy2(img_path, dst_path)
                    # 准备映射：原始绝对路径 -> 新的相对路径
                    new_relative_path = os.path.join('./images', new_filename).replace("\\", "/")
                    replace_map[img_path] = new_relative_path
                    print(f"      - 图片已整合: {filename} -> {new_filename}")
                except Exception as e:
                    print(f"      - [错误] 复制图片 '{img_path}' 失败: {e}")
                    # 如果复制失败，也将其视为不存在
                    not_exist_set.add(img_path)
            else:
                # 如果 quick_analysis 报告的路径不存在，记录下来
                print(f"      - [警告] quick_analysis 报告的图片路径不存在: {img_path}")
                not_exist_set.add(img_path)

        # 第二步: 使用准备好的映射，一次性替换所有路径
        def replace_func(match):
            original_path = match.group(1).strip()

            # 如果图片不存在或复制失败，直接删除整个图片引用
            if original_path in not_exist_set:
                return ''

            # 否则，用新的相对路径替换旧的绝对路径
            new_path = replace_map.get(original_path, original_path)
            return match.group(0).replace(original_path, new_path)

        new_content = pattern.sub(replace_func, content)
        return new_content

    def _tool_writer_editor(self, current_content: str, modifications: list, new_references: list = None):
        """工具3: 修改与写作"""
        print("    -> [工具] 写作官启动，开始应用修改...")
        modified_content = current_content

        # 1. 应用文本修改
        for mod in modifications:
            loc = mod.get("location", {})
            starts_with = loc.get("starts_with")
            ends_with = loc.get("ends_with")
            new_text = mod.get("new_content")

            if not (starts_with and ends_with and new_text is not None):
                print("      - [警告] 修改指令不完整，已跳过。")
                continue

            pattern_str = re.escape(starts_with) + r'.*?' + re.escape(ends_with)
            pattern = re.compile(pattern_str, re.DOTALL)
            modified_content, num_replacements = pattern.subn(new_text, modified_content, count=1)

            if num_replacements > 0:
                print(f"      - 成功定位并替换了以 '{starts_with[:20]}...' 开头的段落。")
            else:
                print(f"      - [警告] 未能定位到要修改的段落: '{starts_with[:20]}...'. 已跳过。")

        # 2. 更新参考文献
        if new_references:
            print("      - 正在更新参考文献...")
            ref_section_match = re.search(r'(#+\s*引用文献\s*|#+\s*数据来源与免责声明\s*)(.*)', modified_content,
                                          re.DOTALL | re.IGNORECASE)

            if ref_section_match:
                header = ref_section_match.group(1)
                existing_refs_text = ref_section_match.group(2)
                existing_ids = [int(i) for i in re.findall(r'\[(\d+)\]', existing_refs_text)]
                max_id = max(existing_ids) if existing_ids else 0

                new_refs_text = ""
                for ref in new_references:
                    # 自动分配新的ID
                    max_id += 1
                    ref_id = ref.get("id", max_id)
                    new_refs_text += f"\n[{ref_id}] {ref.get('title')}: {ref.get('url')}"

                updated_ref_section = header + existing_refs_text.strip() + new_refs_text
                modified_content = modified_content.replace(ref_section_match.group(0), updated_ref_section)
                print(f"      - 已追加 {len(new_references)} 条新引用。")
            else:
                print("      - 未找到现有文献部分，在文末创建新部分。")
                new_refs_text = ""
                max_id = 0
                for ref in new_references:
                    max_id += 1
                    ref_id = ref.get("id", max_id)
                    new_refs_text += f"\n[{ref_id}] {ref.get('title')}: {ref.get('url')}\n"
                modified_content += new_refs_text

        return modified_content

    def save_markdown(self, content, output_file):
        """保存markdown文件"""
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"\n📁 深度财务研报分析已保存到: {output_file}")

    def format_markdown(self, output_file):
        """格式化markdown文件"""
        try:
            import subprocess
            format_cmd = ["mdformat", output_file]
            subprocess.run(format_cmd, check=True, capture_output=True, text=True, encoding='utf-8')
            print(f"✅ 已用 mdformat 格式化 Markdown 文件: {output_file}")
        except Exception as e:
            print(f"[提示] mdformat 格式化失败: {e}\n请确保已安装 mdformat (pip install mdformat)")

    def _convert_mermaid_to_image(self, mermaid_code, output_dir):
        """
        将单段Mermaid代码转换为图片。
        使用 mermaid-py 库进行渲染。
        返回图片路径，如果失败则返回None。
        """
        try:
            import mermaid as md
        except ImportError:
            print("[警告] 未安装 'mermaid-py' 库，无法渲染Mermaid图。请运行: pip install mermaid-py")
            return None

        try:
            # 为图片生成唯一的文件名
            image_name = f"mermaid-{uuid.uuid4().hex}.png"
            image_path = os.path.join(output_dir, image_name)

            # 使用 mermaid-py 渲染
            # 创建Mermaid对象并渲染为PNG
            renderer = md.Mermaid(mermaid_code)
            renderer.to_png(image_path)

            if os.path.exists(image_path):
                print(f"  - Mermaid图已成功渲染为: {os.path.basename(image_path)}")
                return image_path
            else:
                # 尝试从API响应中获取更详细的错误信息
                error_info = ""
                if hasattr(renderer, 'img_response') and hasattr(renderer.img_response, 'content'):
                    error_info = renderer.img_response.content.decode(errors='ignore')
                raise Exception(f"mermaid-py 未能生成图片文件。API响应: {error_info}")

        except Exception as e:
            print(f"[警告] 一处Mermaid图渲染失败 (已跳过): {e}")
            return None

    def convert_to_docx(self, output_file, docx_output=None):
        """
        转换为Word文档，并自动处理Mermaid图表。
        """
        if docx_output is None:
            docx_output = output_file.replace('.md', '.docx')

        try:
            import subprocess
            import tempfile
            # 创建一个临时目录来存放处理后的MD文件和渲染的图片
            with tempfile.TemporaryDirectory() as temp_dir:
                # 1. 读取原始Markdown文件内容
                with open(output_file, 'r', encoding='utf-8') as f:
                    content = f.read()

                # 2. 查找并处理所有Mermaid代码块
                mermaid_pattern = r'```mermaid(.*?)```'
                replacements = []

                # 使用re.DOTALL(或s标志)来匹配包括换行符在内的任意字符
                matches = list(re.finditer(mermaid_pattern, content, re.DOTALL))

                if matches:
                    print("\n[信息] 检测到Mermaid图表，开始渲染...")

                for match in matches:
                    mermaid_code = match.group(1).strip()

                    # 渲染为图片，保存在临时目录中
                    img_path = self._convert_mermaid_to_image(mermaid_code, temp_dir)

                    # 准备替换内容
                    if img_path:
                        # Pandoc需要相对路径，并配合--resource-path使用
                        relative_img_path = os.path.basename(img_path)
                        replacement = f'![Mermaid Diagram]({relative_img_path})'
                    else:
                        replacement = '`[Mermaid图表渲染失败]`'  # 渲染失败时的占位符

                    replacements.append((match.start(), match.end(), replacement))

                # 3. 从后向前替换，避免索引错位
                if replacements:
                    print("[信息] 正在将Mermaid图表替换为图片链接...")
                for start, end, replacement in sorted(replacements, key=lambda x: x[0], reverse=True):
                    content = content[:start] + replacement + content[end:]

                # 4. 将处理后的内容写入临时Markdown文件
                processed_md_path = os.path.join(temp_dir, "processed_report.md")
                with open(processed_md_path, 'w', encoding='utf-8') as f:
                    f.write(content)

                # 5. 修改Pandoc命令以使用处理后的文件和资源路径
                print("[信息] 正在调用 pandoc 生成Word文档...")
                pandoc_cmd = [
                    "pandoc",
                    processed_md_path,  # 输入文件是处理后的临时MD文件
                    "-o",
                    docx_output,
                    "--standalone",
                    "--resource-path", temp_dir,  # 关键：告诉Pandoc在哪里找图片
                ]

                env = os.environ.copy()
                env['PYTHONIOENCODING'] = 'utf-8'

                # 运行Pandoc
                result = subprocess.run(pandoc_cmd, check=False, capture_output=True, text=True, encoding='utf-8',
                                        env=env)

                # 手动检查结果，以便打印更详细的错误信息
                if result.returncode != 0:
                    raise subprocess.CalledProcessError(result.returncode, pandoc_cmd, output=result.stdout,
                                                        stderr=result.stderr)

            print(f"\n📄 Word版报告已生成: {docx_output}")

        except FileNotFoundError:
            print(f"[提示] 转换失败。请确保已安装 pandoc 并将其添加到了系统 PATH。")
        except subprocess.CalledProcessError as e:
            print(f"[提示] pandoc转换失败。错误信息: {e.stderr}")
            print("[建议] 检查pandoc是否能正常工作。")
        except Exception as e:
            print(f"[提示] 生成Word文档过程中发生未知错误: {e}")

        # 无论成功与否，都返回预期的路径，便于上层逻辑处理
        return docx_output

    # ========== 图片处理相关方法 ==========

    def ensure_dir(self, path):
        """确保目录存在"""
        if not os.path.exists(path):
            os.makedirs(path)

    def is_url(self, path):
        """判断是否为URL"""
        return path.startswith('http://') or path.startswith('https://')

    def download_image(self, url, save_path):
        """下载图片"""
        try:
            resp = requests.get(url, stream=True, timeout=10)
            resp.raise_for_status()
            with open(save_path, 'wb') as f:
                for chunk in resp.iter_content(1024):
                    f.write(chunk)
            return True
        except Exception as e:
            print(f"[下载失败] {url}: {e}")
            return False

    def copy_image(self, src, dst):
        """复制图片"""
        try:
            shutil.copy2(src, dst)
            return True
        except Exception as e:
            print(f"[复制失败] {src}: {e}")
            return False

    def extract_images_from_markdown(self, md_path, images_dir, new_md_path):
        """从markdown中提取图片"""
        self.ensure_dir(images_dir)
        with open(md_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # 匹配 ![alt](path) 形式的图片
        pattern = re.compile(r'!\[[^\]]*\]\(([^)]+)\)')
        matches = pattern.findall(content)
        used_names = set()
        replace_map = {}
        not_exist_set = set()

        for img_path in matches:
            img_path = img_path.strip()
            # 取文件名
            if self.is_url(img_path):
                filename = os.path.basename(urlparse(img_path).path)
            else:
                filename = os.path.basename(img_path)
            # 防止重名
            base, ext = os.path.splitext(filename)
            i = 1
            new_filename = filename
            while new_filename in used_names:
                new_filename = f"{base}_{i}{ext}"
                i += 1
            used_names.add(new_filename)
            new_img_path = os.path.join(images_dir, new_filename)
            # 下载或复制
            img_exists = True
            if self.is_url(img_path):
                success = self.download_image(img_path, new_img_path)
                if not success:
                    img_exists = False
            else:
                # 支持绝对和相对路径
                abs_img_path = img_path
                if not os.path.isabs(img_path):
                    abs_img_path = os.path.join(os.path.dirname(md_path), img_path)
                if not os.path.exists(abs_img_path):
                    print(f"[警告] 本地图片不存在: {abs_img_path}")
                    img_exists = False
                else:
                    self.copy_image(abs_img_path, new_img_path)
            # 记录替换
            if img_exists:
                replace_map[img_path] = f'./images/{new_filename}'
            else:
                not_exist_set.add(img_path)

        # 替换 markdown 内容，不存在的图片直接删除整个图片语法
        def replace_func(match):
            orig = match.group(1).strip()
            if orig in not_exist_set:
                return ''  # 删除不存在的图片语法
            return match.group(0).replace(orig, replace_map.get(orig, orig))

        new_content = pattern.sub(replace_func, content)
        with open(new_md_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"图片处理完成！新文件: {new_md_path}")

    def parse_llm_json_output(self, text: str) -> list | dict:
        """
        一个健壮的函数，用于从LLM可能返回的各种格式中提取并解析JSON。
        它能处理 ```json ... ``` 代码块，也能处理裸露的JSON。
        它能正确处理JSON对象 ({...}) 和JSON数组 ([...])。
        """
        # 策略1: 优先尝试精确匹配 ```json ... ``` 代码块
        json_match = re.search(r'```json\s*([\s\S]*?)\s*```', text)
        if json_match:
            json_str = json_match.group(1)
            try:
                return json.loads(json_str)
            except json.JSONDecodeError as e:
                print(f"🚨 JSON解析失败 (在```json块内): {e}\n块内容: '{json_str}'")
                # 即使块内解析失败，也尝试回退策略
                pass

        # 策略2: 这能处理没有代码块或者代码块格式不正确的情况
        try:
            # 查找JSON的起始位置
            first_bracket = text.find('[')
            first_brace = text.find('{')

            if first_bracket == -1 and first_brace == -1:
                raise ValueError("在文本中找不到有效的JSON起始字符'['或'{'。")

            if first_bracket == -1:
                json_start = first_brace
            elif first_brace == -1:
                json_start = first_bracket
            else:
                json_start = min(first_bracket, first_brace)

            # 查找JSON的结束位置
            last_bracket = text.rfind(']')
            last_brace = text.rfind('}')
            json_end = max(last_bracket, last_brace)

            if json_end == -1:
                raise ValueError("在文本中找不到有效的JSON结束字符']'或'}'。")

            # 提取并解析
            json_str = text[json_start: json_end + 1]
            return json.loads(json_str)

        except (json.JSONDecodeError, ValueError) as e:
            print(f"🚨 JSON解析失败 (回退模式): {e}\n原始文本: '{text}'")
            # 在您的工作流中，返回空列表是安全的，可以防止程序崩溃
            return []


def main():
    """主函数"""
    import argparse

    # 添加命令行参数支持
    parser = argparse.ArgumentParser(description='整合的金融研报生成器')
    parser.add_argument('--search-engine', choices=['ddg', 'sogou'], default='sogou',
                        help='搜索引擎选择: ddg (DuckDuckGo) 或 sogou (搜狗), 默认: ddg')
    parser.add_argument('--company', default='商汤科技', help='目标公司名称')
    parser.add_argument('--code', default='00020', help='股票代码')
    parser.add_argument('--market', default='HK', help='市场代码')

    args = parser.parse_args()

    # 创建生成器实例
    generator = IntegratedResearchReportGenerator(
        target_company=args.company,
        target_company_code=args.code,
        target_company_market=args.market,
        search_engine=args.search_engine
    )

    # 运行完整流程，并接收返回的文件路径
    basic_report_md, deep_report_docx = generator.run_full_pipeline()

    print("\n" + "=" * 100)
    print("🎯 程序执行完毕！生成的文件：")
    print(f"📊 基础分析报告 (Markdown): {basic_report_md}")
    print(f"📋 深度研报 (Word): {deep_report_docx}")
    print("=" * 100)


if __name__ == "__main__":
    main()
