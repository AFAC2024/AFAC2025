#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
URL处理工具模块 - 专门处理各种搜索引擎的重定向URL
"""

import re
import requests
import urllib.parse
from typing import Optional
import logging

logger = logging.getLogger("url_handler")


class URLHandler:
    """URL处理工具类，专门处理各种搜索引擎的重定向URL"""
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
        }
    
    def resolve_redirect_url(self, url: str) -> str:
        """
        解析各种重定向URL，返回真实的目标URL
        
        Args:
            url: 可能包含重定向的URL
            
        Returns:
            解析后的真实URL
        """
        original_url = url.strip()
        
        # 1. 处理搜狗重定向
        if self._is_sogou_redirect(original_url):
            resolved = self._resolve_sogou_redirect(original_url)
            if resolved:
                logger.info(f"搜狗重定向解析成功: {original_url[:50]}... -> {resolved[:50]}...")
                return resolved
        
        # 2. 处理百度重定向
        elif self._is_baidu_redirect(original_url):
            resolved = self._resolve_baidu_redirect(original_url)
            if resolved:
                logger.info(f"百度重定向解析成功: {original_url[:50]}... -> {resolved[:50]}...")
                return resolved
        
        # 3. 处理360搜索重定向
        elif self._is_360_redirect(original_url):
            resolved = self._resolve_360_redirect(original_url)
            if resolved:
                logger.info(f"360重定向解析成功: {original_url[:50]}... -> {resolved[:50]}...")
                return resolved
        
        # 4. 处理其他常见重定向格式
        elif 'redirect' in original_url.lower() or 'jump' in original_url.lower():
            resolved = self._resolve_generic_redirect(original_url)
            if resolved:
                logger.info(f"通用重定向解析成功: {original_url[:50]}... -> {resolved[:50]}...")
                return resolved
        
        # 5. 如果不是重定向URL，直接返回
        return original_url
    
    def _is_sogou_redirect(self, url: str) -> bool:
        """检查是否为搜狗重定向URL"""
        return any([
            'sogou.com/link?' in url,
            url.startswith('/link?url='),
            'sogou.com/web/redirect' in url
        ])
    
    def _is_baidu_redirect(self, url: str) -> bool:
        """检查是否为百度重定向URL"""
        return any([
            'baidu.com/link?' in url,
            'baidu.com/redirect?' in url,
            'baidu.com/baidu.php?' in url
        ])
    
    def _is_360_redirect(self, url: str) -> bool:
        """检查是否为360搜索重定向URL"""
        return any([
            '360.cn/link?' in url,
            'so.com/link?' in url,
            '360.cn/redirect?' in url
        ])
    
    def _resolve_sogou_redirect(self, url: str) -> Optional[str]:
        """解析搜狗重定向URL"""
        try:
            # 处理相对路径
            if url.startswith('/link?url='):
                url = f"https://www.sogou.com{url}"
            
            # 方法1: 直接跟随HTTP重定向
            try:
                response = requests.get(url, headers=self.headers, timeout=15, allow_redirects=True)
                if response.url != url and response.url.startswith(('http://', 'https://')):
                    return response.url
            except Exception as e:
                logger.debug(f"HTTP重定向方法失败: {e}")
            
            # 方法2: 解析URL参数
            try:
                parsed = urllib.parse.urlparse(url)
                query_params = urllib.parse.parse_qs(parsed.query)
                
                # 搜狗常见参数: url, u, link
                for param_name in ['url', 'u', 'link']:
                    if param_name in query_params:
                        target_url = query_params[param_name][0]
                        # 可能需要base64解码或其他解码
                        decoded_url = self._try_decode_url(target_url)
                        if decoded_url.startswith(('http://', 'https://')):
                            return decoded_url
            except Exception as e:
                logger.debug(f"URL参数解析方法失败: {e}")
            
            # 方法3: 获取页面内容并解析JavaScript重定向
            try:
                response = requests.get(url, headers=self.headers, timeout=10, allow_redirects=False)
                content = response.text
                
                # 查找JavaScript重定向
                js_patterns = [
                    r'window\.location\.href\s*=\s*["\']([^"\']+)["\']',
                    r'window\.location\s*=\s*["\']([^"\']+)["\']',
                    r'location\.href\s*=\s*["\']([^"\']+)["\']',
                    r'location\.replace\(["\']([^"\']+)["\']\)',
                    r'top\.location\s*=\s*["\']([^"\']+)["\']'
                ]
                
                for pattern in js_patterns:
                    match = re.search(pattern, content, re.IGNORECASE)
                    if match:
                        target_url = match.group(1)
                        if target_url.startswith(('http://', 'https://')):
                            return target_url
                
                # 查找meta refresh重定向
                meta_pattern = r'<meta[^>]*http-equiv=["\']refresh["\'][^>]*content=["\'][^;"]*url=([^"\']+)["\']'
                meta_match = re.search(meta_pattern, content, re.IGNORECASE)
                if meta_match:
                    target_url = meta_match.group(1)
                    if target_url.startswith(('http://', 'https://')):
                        return target_url
                        
            except Exception as e:
                logger.debug(f"页面内容解析方法失败: {e}")
            
        except Exception as e:
            logger.warning(f"搜狗重定向解析失败: {e}")
        
        return None
    
    def _resolve_baidu_redirect(self, url: str) -> Optional[str]:
        """解析百度重定向URL"""
        try:
            # 直接跟随重定向
            response = requests.get(url, headers=self.headers, timeout=15, allow_redirects=True)
            if response.url != url and response.url.startswith(('http://', 'https://')):
                return response.url
        except Exception as e:
            logger.debug(f"百度重定向解析失败: {e}")
        
        return None
    
    def _resolve_360_redirect(self, url: str) -> Optional[str]:
        """解析360搜索重定向URL"""
        try:
            # 直接跟随重定向
            response = requests.get(url, headers=self.headers, timeout=15, allow_redirects=True)
            if response.url != url and response.url.startswith(('http://', 'https://')):
                return response.url
        except Exception as e:
            logger.debug(f"360重定向解析失败: {e}")
        
        return None
    
    def _resolve_generic_redirect(self, url: str) -> Optional[str]:
        """解析通用重定向URL"""
        try:
            # 尝试跟随重定向
            response = requests.get(url, headers=self.headers, timeout=15, allow_redirects=True)
            if response.url != url and response.url.startswith(('http://', 'https://')):
                return response.url
            
            # 解析URL参数中可能的目标URL
            parsed = urllib.parse.urlparse(url)
            query_params = urllib.parse.parse_qs(parsed.query)
            
            # 常见的重定向参数名
            redirect_params = ['url', 'redirect', 'target', 'to', 'goto', 'link', 'href']
            for param in redirect_params:
                if param in query_params:
                    target_url = query_params[param][0]
                    decoded_url = self._try_decode_url(target_url)
                    if decoded_url.startswith(('http://', 'https://')):
                        return decoded_url
                        
        except Exception as e:
            logger.debug(f"通用重定向解析失败: {e}")
        
        return None
    
    def _try_decode_url(self, encoded_url: str) -> str:
        """尝试解码URL"""
        try:
            # URL解码
            decoded = urllib.parse.unquote(encoded_url)
            if decoded != encoded_url:
                return decoded
        except:
            pass
        
        try:
            # Base64解码 (某些搜索引擎使用)
            import base64
            decoded_bytes = base64.b64decode(encoded_url + '===')  # 添加padding
            decoded = decoded_bytes.decode('utf-8')
            if decoded.startswith(('http://', 'https://')):
                return decoded
        except:
            pass
        
        return encoded_url
    
    def is_valid_url(self, url: str) -> bool:
        """检查URL是否有效"""
        try:
            parsed = urllib.parse.urlparse(url)
            return all([parsed.scheme, parsed.netloc])
        except:
            return False


# 全局实例
url_handler = URLHandler()


def resolve_url(url: str) -> str:
    """便捷函数：解析重定向URL"""
    return url_handler.resolve_redirect_url(url)


if __name__ == "__main__":
    # 测试代码
    test_urls = [
        "/link?url=hedJjaC291PD0T3DYzJqFDoBhFbePHvernilvTOuwmkxsEn-glJVT8WzZv4hV1ndow0p_MnW6SA.",
        "https://www.sogou.com/link?url=hedJjaC291PD0T3DYzJqFDoBhFbePHvernilvTOuwmkxsEn-glJVT8WzZv4hV1ndow0p_MnW6SA.",
        "https://www.baidu.com/link?url=example",
        "https://www.so.com/link?url=example"
    ]
    
    handler = URLHandler()
    
    for test_url in test_urls:
        print(f"原始URL: {test_url}")
        resolved = handler.resolve_redirect_url(test_url)
        print(f"解析后: {resolved}")
        print("-" * 50)
