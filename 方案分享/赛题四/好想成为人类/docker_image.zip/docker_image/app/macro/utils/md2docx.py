import os
import re
import subprocess
import tempfile
# import base64
import shutil
from pathlib import Path
import uuid
import logging
from mermaid import Mermaid
import time

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s - %(name)s] - %(levelname)s - %(message)s"
    )

_logger = logging.getLogger(__name__)


def convert_mermaid_to_image(mermaid_code, output_dir, backend="web"):
    """尝试将Mermaid代码转换为图片，返回图片路径或None（失败时）"""
    try:
        # 生成唯一文件名
        image_name = f"mermaid_{uuid.uuid4().hex}.png"
        image_path = os.path.join(output_dir, image_name)
        
        # 通过mmdc转换Mermaid
        _logger.info(f'=> mermaid_code: \n{mermaid_code}')
        if backend == "mmdc":
            result = subprocess.run(
                ["mmdc", "-i", "-", "-o", image_path],
                input=mermaid_code.encode('utf-8'),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=30  # 设置超时防止卡死
            )
            
            if result.returncode == 0 and os.path.exists(image_path):
                return image_path
        elif backend == "web":
            render = Mermaid(mermaid_code)
            render.to_png(image_path)
            if os.path.exists(image_path):
                return image_path
            else:
                raise Exception(render.img_response.content.decode())
    except Exception as e:
        _logger.error(f"=> Mermaid渲染失败（已跳过）: {str(e)}")
    return None

def convert_md_to_docx_with_mermaid(
    input_md, output_docx, 
    tmp_dir_parent=None, 
    with_mermaid=True,
    mermaid_backend="web",
):
    # 创建临时工作目录
    with tempfile.TemporaryDirectory(dir=tmp_dir_parent) as _tmp_dir:
        # 读取Markdown内容
        with open(input_md, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if with_mermaid:
            # 正则匹配所有Mermaid代码块
            mermaid_pattern = r'(?s)```mermaid(.*?)```'
            replacements = []
            
            # 遍历所有匹配的代码块
            for match in re.finditer(mermaid_pattern, content):
                mermaid_code = match.group(1).strip()
                
                # 尝试渲染为图片
                img_path = convert_mermaid_to_image(mermaid_code, _tmp_dir, mermaid_backend)
                time.sleep(1) # mermaid-py本质为webapi，防止访问过快

                # 构造替换内容（成功：图片标记；失败：空字符串）
                replacement = f'![]({img_path})' if img_path else '[图片编译出错]'
                replacements.append((match.start(), match.end(), replacement))
            
            # 从后向前替换（避免索引偏移）
            for start, end, replacement in sorted(replacements, reverse=True, key=lambda x: x[0]):
                content = content[:start] + replacement + content[end:]
        
        # 写入处理后的临时Markdown
        temp_md = os.path.join(_tmp_dir, "temp.md")
        with open(temp_md, 'w', encoding='utf-8') as f:
            f.write(content)
        
        convert_md_to_docx(
            input_md=temp_md,
            output_docx=output_docx,
            tmp_dir_parent=tmp_dir_parent,
        )
        
        # # 使用Pandoc转换为DOCX（指定资源路径）
        # subprocess.run([
        #     "pandoc", temp_md, 
        #     "-o", output_docx,
        #     "--resource-path", _tmp_dir,
        #     "--lua-filter", "mermaid-filter.lua"  # 可选：基础格式处理
        # ], check=True)

def format_markdown(input_file, output_file):
    """格式化markdown文件"""
    try:
        import subprocess
        shutil.copy2(input_file, output_file)
        format_cmd = ["mdformat", output_file]
        subprocess.run(format_cmd, check=True, capture_output=True, text=True, encoding='utf-8')
        _logger.info(f"✅ 已用 mdformat 格式化 Markdown 文件: {output_file}")
    except Exception as e:
        _logger.error(f"[提示] mdformat 格式化失败: {e}\n请确保已安装 mdformat (pip install mdformat)")
    
    return output_file

def convert_to_docx(input_file, docx_output=None):
    """转换为Word文档"""
    if docx_output is None:
        docx_output = input_file.replace('.md', '.docx')
    try:
        import subprocess
        import os
        pandoc_cmd = [
            "pandoc",
            input_file,
            "-o",
            docx_output,
            "--standalone",
            "--resource-path=.",
            "--extract-media=."
        ]
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        subprocess.run(pandoc_cmd, check=True, capture_output=True, text=True, encoding='utf-8', env=env)
        _logger.info(f"\n📄 Word版报告已生成: {docx_output}")
    except subprocess.CalledProcessError as e:
        _logger.error(f"[提示] pandoc转换失败。错误信息: {e.stderr}")
        _logger.error("[建议] 检查图片路径是否正确，或使用 --extract-media 选项")
    except Exception as e:
        _logger.error(f"[提示] 若需生成Word文档，请确保已安装pandoc。当前转换失败: {e}")

def convert_md_to_docx(input_md, output_docx, tmp_dir_parent=None):
    with tempfile.TemporaryDirectory(dir=tmp_dir_parent) as _tmp_dir:
        convert_to_docx(
            input_file=format_markdown(
                input_file=str(input_md),
                output_file=os.path.join(_tmp_dir, "temp.md"),
            ),
            docx_output=str(output_docx)
        )

# 使用示例
if __name__ == "__main__":
    base_dir = Path("./_old_res_01/outputs/run_20250723_142135/")
    in_path = base_dir / "20250723_143822_行业研报.md"
    out_path = base_dir / "20250723_143822_行业研报.docx"

    convert_md_to_docx_with_mermaid(
        in_path, out_path,
        tmp_dir_parent=base_dir,
        with_mermaid=True
    )

    # convert_to_docx(
    #     input_file=format_markdown(
    #         input_file=in_path,
    #         output_file=in_path.replace(".md", "_tmp.md"),
    #     ),
    #     docx_output=out_path
    # )

    # convert_md_to_docx(
    #     input_md=in_path,
    #     output_docx=in_path.parent / f"{in_path.stem}.docx",
    #     tmp_dir_parent=base_dir,
    # )
