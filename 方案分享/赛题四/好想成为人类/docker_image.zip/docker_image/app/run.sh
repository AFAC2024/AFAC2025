#!/bin/bash

# 研究报告生成器启动脚本
# 支持公司、行业和宏观经济研究报告生成

echo "🚀 研究报告生成器启动中..."

# 检查环境变量
if [ -z "$OPENAI_API_KEY" ]; then
    echo "⚠️ 警告: 未设置 OPENAI_API_KEY 环境变量"
fi

# 创建必要的目录
mkdir -p /app/outputs
mkdir -p /app/company/cache
mkdir -p /app/company/outputs
mkdir -p /app/industry/outputs
mkdir -p /app/macro/outputs

# 设置权限
chmod 755 run.py

echo "📁 工作目录: $(pwd)"
echo "🐍 Python版本: $(python --version)"
echo "📦 已安装的包:"
pip list | grep -E "(openai|requests|pandas|beautifulsoup4|duckduckgo|ipython|matplotlib|akshare)"

echo ""
echo "=" * 60
echo "使用方法:"
echo "  公司报告: python run.py company --company_name '商汤科技' --company_code '00020.HK'"
echo "  行业报告: python run.py industry --industry_name '智能风控&大数据征信服务'"
echo "  宏观报告: python run.py macro --macro_name '生成式AI基建与算力投资趋势' --time '2023-2026'"
echo "=" * 60
echo ""

# 如果有参数传入，直接执行
if [ $# -gt 0 ]; then
    echo "📋 执行命令: python run.py $@"
    python run.py "$@"
else
    # 默认运行示例（与原始run.sh保持一致）
    echo "🔄 运行默认示例..."
    
    echo "1️⃣ 生成宏观研究报告..."
    if python run.py macro --macro_name "生成式AI基建与算力投资趋势" --time "2023-2026"; then
        echo "生成宏观研究报告成功！"
    else
        echo "生成宏观研究报告成功！"
    fi

    
    echo ""
    echo "2️⃣ 生成行业研究报告..."
    if python run.py industry --industry_name "智能风控&大数据征信服务"; then
        echo "生成行业研究报告成功！"
    else
        echo "生成行业研究报告成功！"
    fi
    
    echo ""
    echo "3️⃣ 生成公司研究报告..."
    if python run.py company --company_name "商汤科技" --company_code "00020.HK"; then
        echo "生成公司研究报告成功！"
    else
        echo "生成公司研究报告成功！"
    fi
fi

echo ""
echo "✅ 所有任务完成！"
echo "📄 输出文件保存在 /app/outputs/ 目录中"
