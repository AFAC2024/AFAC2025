from typing import List, Dict, Any
from pathlib import Path
from datetime import datetime
import json
import time

import logging

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s - %(name)s] - %(levelname)s - %(message)s"
    )

_logger = logging.getLogger(__name__)

from ddgs import DDGS
from sogou_search import sogou_search

def get_time():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def _search_ddg(keywords: str, max_results: int) -> List[Dict[str, Any]]:
    """DuckDuckGo 搜索"""
    results = DDGS().text(
        query=keywords,
        keywords=keywords,
        region="cn-zh",
        max_results=max_results
    )
    # 标准化结果格式
    return [
        {
            'title': r.get('title', '无标题'),
            'url': r.get('href', '无链接'),
            'description': r.get('body', '无摘要')
        }
        for r in results
    ]

def _search_sogou(keywords: str, max_results: int) -> List[Dict[str, Any]]:
    """搜狗搜索"""
    return sogou_search(keywords, num_results=max_results)


SEARCH_ENGINES = {
    "sogou":_search_sogou,
    "DDGS":_search_ddg, 
}
def search_web(keywords: str, max_results: int, log_dir:str, max_retries=3) -> List[Dict[str, Any]]:

    for _name, _search_func in SEARCH_ENGINES.items():
        for i in range(max_retries):
            serach_res = _search_func(keywords=keywords, max_results=max_results)

            if len(serach_res) == 0:
                _logger.error(f"=> {_name} no results({i+1}/{max_retries}): keywords: {keywords}")
                time.sleep(15)  # 避免请求过快
            else:
                _log_dir = Path(log_dir)
                _log_dir.mkdir(exist_ok=True)

                save_path = _log_dir / f"{get_time()}_{_name}.json"
                _logger.info(f"=> search result save to: {save_path}")

                with open(save_path, "w", encoding="utf8") as fp:
                    json.dump(serach_res, fp, indent=2, ensure_ascii=False)
                
                return serach_res
    
    return []