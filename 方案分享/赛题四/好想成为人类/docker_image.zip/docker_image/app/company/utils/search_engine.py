"""
搜索引擎封装模块
支持 DuckDuckGo、Sogou 和 Bing 三种搜索方式
"""

import random
import time
import hashlib
import json
import os
import requests
from bs4 import BeautifulSoup
from typing import List, Dict, Any
from duckduckgo_search import DDGS

# 尝试导入搜狗搜索，如果失败则只支持DDG
try:
    from sogou_search import sogou_search

    SOGOU_AVAILABLE = True
except ImportError:
    SOGOU_AVAILABLE = False


class SearchEngine:
    """搜索引擎封装类"""

    def __init__(self, engine: str = "ddg", cache_dir: str = "./cache"):
        """
        初始化搜索引擎

        Args:
            engine: 搜索引擎类型，支持 "ddg" (DuckDuckGo)、"sogou" (搜狗) 和 "bing" (Bing)
            cache_dir: 缓存目录路径
        """
        self.engine = engine.lower()
        self.delay = (1.0, 3.0)  # 搜索间隔时间范围（秒）
        self.cache_dir = cache_dir

        # 创建缓存目录
        os.makedirs(cache_dir, exist_ok=True)
        self.cache_file = os.path.join(cache_dir, "url_cache.json")

        # 加载缓存
        self.url_cache = self._load_cache()

        if self.engine not in ["ddg", "sogou", "bing"]:
            raise ValueError(f"不支持的搜索引擎: {engine}. 支持的类型: 'ddg', 'sogou', 'bing'")

        if self.engine == "sogou" and not SOGOU_AVAILABLE:
            print("警告: 搜狗搜索 (k_sogou_search) 未安装, 将回退到 DuckDuckGo。")
            self.engine = "ddg"

    def _load_cache(self) -> Dict[str, Dict[str, Any]]:
        """加载URL缓存"""
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            print(f"加载缓存失败: {e}")
        return {}

    def _save_cache(self):
        """保存URL缓存"""
        try:
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.url_cache, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存缓存失败: {e}")

    def _get_url_hash(self, url: str) -> str:
        """获取URL的哈希值"""
        return hashlib.md5(url.encode('utf-8')).hexdigest()

    def _filter_cached_results(self, results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """过滤已缓存的结果，返回新结果并更新缓存"""
        new_results = []
        cache_updated = False

        for result in results:
            url = result.get('url', '')
            if not url or url == '无链接':
                continue

            url_hash = self._get_url_hash(url)

            # 检查是否已缓存
            if url_hash in self.url_cache:
                print(f"[Sogou🐶] 跳过已缓存的URL: {url[:50]}...")
                continue

            # 添加到缓存
            self.url_cache[url_hash] = {
                'url': url,
                'title': result.get('title', '无标题'),
                'description': result.get('description', '无摘要'),
                'cached_time': time.time()
            }
            new_results.append(result)
            cache_updated = True

        # 保存缓存
        if cache_updated:
            self._save_cache()

        return new_results

    def search(self, keywords: str, max_results: int = 10) -> List[Dict[str, Any]]:
        """
        统一搜索接口，按照 Sogou -> DuckDuckGo -> Bing 的顺序回退

        Args:
            keywords: 搜索关键词
            max_results: 最大结果数

        Returns:
            搜索结果列表，每个结果包含 title, url, description 字段
        """
        print(f"[搜索🔍] 开始搜索: '{keywords}'")

        # 按顺序尝试搜索引擎
        search_engines = ["sogou", "ddg", "bing"]
        if self.engine != "sogou":
            # 如果初始化时指定了其他引擎，将其放在第一位
            search_engines = [self.engine] + [e for e in search_engines if e != self.engine]

        for engine in search_engines:
            try:
                print(f"[搜索🔍] 尝试使用 {engine.upper()} 搜索引擎")

                if engine == "ddg":
                    results = self._search_ddg(keywords, max_results)
                elif engine == "sogou":
                    if not SOGOU_AVAILABLE:
                        print("❗Sogou 搜索不可用，跳过")
                        continue
                    results = self._search_sogou(keywords, max_results)
                elif engine == "bing":
                    results = self._search_bing(keywords, max_results)
                else:
                    continue

                if results:
                    # 过滤已缓存的结果
                    new_results = self._filter_cached_results(results)
                    print(f"[{engine.upper()}] 搜索成功！原始结果: {len(results)} 条，新结果: {len(new_results)} 条")
                    time.sleep(random.uniform(*self.delay))
                    return new_results
                else:
                    print(f"❗{engine.upper()} 无结果或被拦截，尝试下一个搜索引擎")

            except Exception as e:
                print(f"❗{engine.upper()} 搜索失败: {e}")
                continue

        print("❗所有搜索引擎都失败了")
        return []

    def _search_ddg(self, keywords: str, max_results: int) -> List[Dict[str, Any]]:
        """DuckDuckGo 搜索"""
        results = DDGS().text(
            keywords=keywords,
            region="cn-zh",
            max_results=max_results
        )
        # 标准化结果格式
        return [
            {
                'title': r.get('title', '无标题'),
                'url': r.get('href', '无链接'),
                'description': r.get('body', '无摘要')
            }
            for r in results
        ]

    def _search_sogou(self, keywords: str, max_results: int) -> List[Dict[str, Any]]:
        """搜狗搜索"""
        if not SOGOU_AVAILABLE:
            return []

        # 第一次请求
        results = sogou_search(keywords, num_results=max_results)
        if not results:
            # 被拦截或无结果，稍等再试一次
            print("[Sogou🐶] Warning: 搜狗首次返回空，等待后重试…")
            time.sleep(random.uniform(*self.delay))
            results = sogou_search(keywords, num_results=max_results)
        return results

    def _search_bing(self, keywords: str, max_results: int) -> List[Dict[str, Any]]:
        """Bing 搜索"""
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }

        # Bing 搜索 URL
        search_url = f"https://www.bing.com/search?q={keywords}&count={max_results}"

        try:
            response = requests.get(search_url, headers=headers, timeout=10)
            response.raise_for_status()

            soup = BeautifulSoup(response.text, 'html.parser')
            results = []

            # 解析搜索结果
            search_results = soup.find_all('li', class_='b_algo')

            for result in search_results[:max_results]:
                try:
                    # 提取标题
                    title_elem = result.find('h2')
                    title = title_elem.get_text().strip() if title_elem else '无标题'

                    # 提取链接
                    link_elem = title_elem.find('a') if title_elem else None
                    url = link_elem.get('href') if link_elem else '无链接'

                    # 提取描述
                    desc_elem = result.find('p') or result.find('div', class_='b_caption')
                    description = desc_elem.get_text().strip() if desc_elem else '无摘要'

                    if title != '无标题' and url != '无链接':
                        results.append({
                            'title': title,
                            'url': url,
                            'description': description
                        })

                except Exception as e:
                    print(f"[Bing] 解析单个结果失败: {e}")
                    continue

            print(f"[Bing🔍] 解析到 {len(results)} 条结果")
            return results

        except requests.RequestException as e:
            print(f"[Bing🔍] 请求失败: {e}")
            return []
        except Exception as e:
            print(f"[Bing🔍] 解析失败: {e}")
            return []

    def get_cache_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息"""
        return {
            'total_cached_urls': len(self.url_cache),
            'cache_file': self.cache_file,
            'cache_size_mb': os.path.getsize(self.cache_file) / (1024 * 1024) if os.path.exists(self.cache_file) else 0
        }

    def clear_cache(self):
        """清空缓存"""
        self.url_cache = {}
        if os.path.exists(self.cache_file):
            os.remove(self.cache_file)
        print("[Sogou🐶] 缓存已清空")


if __name__ == "__main__":
    # 测试代码
    print("[搜索�] 测试搜索引擎封装...")

    # 测试 DuckDuckGo
    print("\n=== 测试 DuckDuckGo ===")
    ddg_engine = SearchEngine(engine="ddg")
    ddg_results = ddg_engine.search("商汤科技", max_results=2)
    for i, result in enumerate(ddg_results, 1):
        print(f"{i}. {result['title']}")
        print(f"   URL: {result['url']}")
        print(f"   描述: {result['description'][:100]}...")

    # 测试搜狗（如果可用）
    if SOGOU_AVAILABLE:
        print("\n=== 测试搜狗搜索 ===")
        sogou_engine = SearchEngine(engine="sogou")
        sogou_results = sogou_engine.search("商汤科技", max_results=2)
        for i, result in enumerate(sogou_results, 1):
            print(f"{i}. {result['title']}")
            print(f"   URL: {result['url']}")
            print(f"   描述: {result['description'][:100]}...")
    else:
        print("\n=== 搜狗搜索不可用 (k_sogou_search 未安装) ===")

    # 测试 Bing
    print("\n=== 测试 Bing 搜索 ===")
    bing_engine = SearchEngine(engine="bing")
    bing_results = bing_engine.search("商汤科技", max_results=2)
    for i, result in enumerate(bing_results, 1):
        print(f"{i}. {result['title']}")
        print(f"   URL: {result['url']}")
        print(f"   描述: {result['description'][:100]}...")

    # 测试自动回退功能
    print("\n=== 测试自动回退功能 ===")
    auto_engine = SearchEngine(engine="sogou")  # 优先使用搜狗
    auto_results = auto_engine.search("商汤科技", max_results=2)
    print(f"自动回退搜索获得 {len(auto_results)} 条结果")
