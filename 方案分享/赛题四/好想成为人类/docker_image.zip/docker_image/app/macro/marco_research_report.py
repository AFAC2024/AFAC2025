import os
import time
import yaml
import openai
import copy
import logging
import json
import hashlib
from datetime import datetime
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv
# from duckduckgo_search import DDGS
from ddgs import DDGS
from pocketflow import Node
import re
from typing import List, Dict

from .knowledge_base import KnowledgeBase, extract_content_from_url
from .utils.md2docx import convert_md_to_docx_with_mermaid
from .utils.search_engine import SearchEngine, SOGOU_AVAILABLE, sogou_search
from .prompts import *

# ------------------------------------------------------------------------------
# 配置与全局变量
# ------------------------------------------------------------------------------
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")
openai.api_base = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")

# 最大重复搜索次数
MAX_SEARCH_ATTEMPTS = int(os.getenv("MAX_SEARCH_ATTEMPTS", "4"))

# 输出目录
os.makedirs("./macro_outputs/decision_process/", exist_ok=True)
os.makedirs("./macro_outputs/sections/", exist_ok=True)
os.makedirs("./macro_outputs/prompts/", exist_ok=True)
os.makedirs("./macro_outputs/knowledge_base/", exist_ok=True)  # 本地知识库目录

# 日志初始化
logger = logging.getLogger("macro_workflow")
logger.setLevel(logging.INFO)
file_handler = logging.FileHandler('macro_workflow.log', encoding='utf-8')
file_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s'))
logger.addHandler(file_handler)


# ------------------------------------------------------------------------------
# 通用 LLm 调用
# ------------------------------------------------------------------------------
def call_llm(prompt: str) -> str:
    resp = openai.chat.completions.create(
        model=os.getenv("OPENAI_MODEL", "gpt-4"),
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )
    return resp.choices[0].message.content.strip()


# ------------------------------------------------------------------------------
# 本地知识库管理
# ------------------------------------------------------------------------------

# KnowledgeBase 类已移到 knowledge_base.py 文件中

# 全局知识库实例
knowledge_base = KnowledgeBase()


def extract_yaml(resp: str) -> str:
    """
    优先从 ```yaml … ``` code fence 里提取内容，
    如果没找到，就回退把整个 resp 当作 YAML 文本。
    """
    # 1) 匹配 ```yaml\s*(.*?)```，提取 YAML 内容
    m = re.search(r"```yaml\s*(.*?)```", resp, re.DOTALL | re.IGNORECASE)
    if m:
        return m.group(1).strip()
    # 2) 匹配任意 ```，提取内容
    m2 = re.search(r"```(.*?)```", resp, re.DOTALL)
    if m2:
        return m2.group(1).strip()
    # 3) 回退，返回整个响应
    logger.warning("extract_yaml: 未找到 code fence，回退使用整个响应")
    return resp.strip()

def parse_decision(resp: str) -> dict:
    """
    解析决策节点 LLM 响应，返回 {'action':..., 'reason':..., 'remove_indices':..., 'remove_reason':...}。
    先 extract_yaml + yaml.safe_load，失败后用正则 fallback。
    """
    text = extract_yaml(resp)
    # 去掉包裹的单/双引号
    if (text.startswith(("'", '"')) and text.endswith(("'", '"'))):
        text = text[1:-1].strip()
    # 先尝试 YAML 解析
    try:
        data = yaml.safe_load(text)
        return {
            "action": data.get("action"),
            "reason": data.get("reason", ""),
            "search_terms": data.get("search_terms", []),
            "remove_indices": data.get("remove_indices", []),
            "remove_reason": data.get("remove_reason", ""),
        }
    except Exception as e:
        logger.warning(f"YAML 解析失败，fallback to regex: {e}")
        # 正则抽 action
        act_m = re.search(r"action\s*[:：]\s*(search|generate)", text, re.IGNORECASE)
        reason_m = re.search(r"reason\s*[:：]\s*(.*)", text, re.IGNORECASE | re.DOTALL)
        action = act_m.group(1).lower() if act_m else None
        reason = reason_m.group(1).strip() if reason_m else ""
        
        # 尝试提取remove_indices (简单的正则匹配)
        remove_indices = []
        remove_reason = ""
        remove_indices_m = re.search(r"remove_indices\s*[:：]\s*\[(.*?)\]", text, re.DOTALL | re.IGNORECASE)
        if remove_indices_m:
            indices_text = remove_indices_m.group(1)
            # 提取数字
            index_matches = re.findall(r'\d+', indices_text)
            remove_indices = [int(idx) for idx in index_matches]
        
        remove_reason_m = re.search(r"remove_reason\s*[:：]\s*[\"']([^\"']*)[\"']", text, re.IGNORECASE)
        if remove_reason_m:
            remove_reason = remove_reason_m.group(1)
        
        return {
            "action": action, 
            "reason": reason,
            "search_terms": [],
            "remove_indices": remove_indices,
            "remove_reason": remove_reason,
        }



# ------------------------------------------------------------------------------
# 节点定义
# ------------------------------------------------------------------------------

class PlanSections(Node):
    """第一步：规划整个研报的章节列表"""
    def prep(self, shared):
        return shared["industry"], shared.get("focus_areas", [])

    def exec(self, inputs):
        industry, focus_areas = inputs
        prompt = PLAN_SECTIONS_PROMPT.format(industry=industry)
        
        # 保存prompt到本地
        prompt_file = f"./macro_outputs/prompts/plan_sections_prompt.txt"
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write(prompt)
        logger.info(f"[PlanSections] Saved prompt → {prompt_file}")
        
        resp = call_llm(prompt)
        yaml_text = extract_yaml(resp)
        try:
            sections = yaml.safe_load(yaml_text)
        except Exception as e:
            logger.error(f"PlanSections YAML 解析失败，raw_resp:\n{resp}\nError: {e}")
            raise
        return sections
    
    def post(self, shared, prep_res, exec_res):
        shared["sections_plan"] = exec_res
        shared["search_attempts"] = {}  # 初始化每章节搜索计数
        shared["context"] = []
        return None
    
    
class IndustryResearchFlow(Node):
    """每个章节的决策节点：判断是继续搜索还是生成"""
    def __init__(self, max_search_attempts=5):
        super().__init__()
        self.max_search = max_search_attempts
        self._cached_shared = None
        self._last_section_name = None

    def prep(self, shared):
        # 如果章节变了，记录新章节名
        cur_sec = shared.get("current_section", {}).get("name")
        if cur_sec and cur_sec != self._last_section_name:
            self._last_section_name = cur_sec
            # 不需要加载到 shared["context"]，决策时直接从知识库读取

        self._cached_shared = shared
        industry     = shared["industry"]
        section      = shared["current_section"]
        focus_areas  = shared.get("focus_areas", [])
        
        # 直接从知识库获取当前章节内容用于决策
        cached_content = knowledge_base.get_all_content_for_section(cur_sec)
        
        # 为每条信息添加索引，便于决策时删除
        indexed_content = []
        for i, content in enumerate(cached_content):
            indexed_item = content.copy()
            indexed_item['index'] = i  # 添加索引
            indexed_content.append(indexed_item)
        
        context_str  = yaml.dump(indexed_content, allow_unicode=True)
        
        return industry, context_str, section, focus_areas, cached_content

    def exec(self, inputs):
        industry, context_str, section, focus_areas, cached_content = inputs
        sec_name = section["name"]

        # 获取当前章节的决策次数（包括当前这次）
        current_attempt = self._cached_shared["search_attempts"].get(sec_name, 0) + 1
        
        # 保存当前状态 - 包含决策次数
        safe_name = sec_name.replace(' ', '_').replace('/', '_').replace('\\', '_')
        state_file = f"./macro_outputs/decision_process/decision_{safe_name}_attempt_{current_attempt}.yaml"
        with open(state_file, 'w', encoding='utf-8') as f:
            yaml.dump(self._cached_shared, f, allow_unicode=True)
        logger.info(f"[Decision] Saved state for section '{sec_name}' (attempt {current_attempt}) → {state_file}")

        # 构造决策提示
        prompt = INDUSTRY_RESEARCH_FLOW_PROMPT.format(
            sec_name=sec_name,
            section_focus=section['focus'],
            context_count=len(yaml.safe_load(context_str)) if context_str.strip() else 0,
            context_str=context_str
        )
        
        # 保存prompt到本地 - 包含决策次数
        prompt_file = f"./macro_outputs/prompts/decision_prompt_{safe_name}_attempt_{current_attempt}.txt"
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write(prompt)
        logger.info(f"[Decision] Saved prompt for section '{sec_name}' (attempt {current_attempt}) → {prompt_file}")
        
        resp = call_llm(prompt)
        result = parse_decision(resp)

        # 强制生成（超出最大搜索次数）
        attempts = self._cached_shared["search_attempts"].get(sec_name, 0)
        if result["action"] == "search" and attempts >= self.max_search:
            logger.info(f"[Decision] section '{sec_name}' 达到最大搜索次数({attempts})，强制生成")
            result["action"] = "generate"
            result["reason"] += f"（达到最大搜索次数 {self.max_search}）"

        logger.info(f"[Decision] section '{sec_name}' → action={result['action']}, reason={result['reason']}")
        return result

    def post(self, shared, prep_res, exec_res):
        sec_name = shared["current_section"]["name"]
        action = exec_res["action"]
        
        # 处理知识库清理 - 使用索引而不是URL
        remove_indices = exec_res.get("remove_indices", [])
        remove_reason = exec_res.get("remove_reason", "")
        
        if remove_indices:
            # 从prep_res中获取原始内容列表
            industry, context_str, section, focus_areas, cached_content = prep_res
            
            # 根据索引获取要删除的URLs
            remove_urls = []
            for idx in remove_indices:
                if 0 <= idx < len(cached_content):
                    remove_urls.append(cached_content[idx]["url"])
                else:
                    logger.warning(f"[Decision] Invalid index {idx}, skipping (total items: {len(cached_content)})")
            
            if remove_urls:
                logger.info(f"[Decision] Processing knowledge base cleanup for section '{sec_name}': {len(remove_urls)} URLs to remove (indices: {remove_indices})")
                removal_results = knowledge_base.remove_multiple_urls(remove_urls, sec_name, remove_reason)
                print(f"[Decision] Removal results: {removal_results}")

                if removal_results["success"]:
                    logger.info(f"[Decision] Successfully removed {len(removal_results['success'])} URLs from knowledge base")
                
                if removal_results["failed"]:
                    logger.warning(f"[Decision] Failed to remove {len(removal_results['failed'])} URLs: {removal_results['failed']}")
        
        if action == "search":
            shared["search_attempts"][sec_name] = shared["search_attempts"].get(sec_name, 0) + 1

            # 仅使用 LLM 返回的关键词列表
            terms = exec_res.get("search_terms", [])
            if not terms:
                logger.warning(f"section '{sec_name}' 未返回 search_terms，列表为空")

            shared["search_terms"] = terms
            return "search"
        else:
            return "generate"
        

class SearchInfo(Node):
    """信息搜索节点"""
    
    def __init__(self, engine_type="sogou", cache_dir="./cache"):
        super().__init__()
        self.engine = SearchEngine(engine=engine_type, cache_dir=cache_dir)
    
    def prep(self, shared):
        return shared.get("search_terms", [])

    def exec(self, search_terms):
        all_results = []
        for term in search_terms:
            print(f"\n搜索关键词: {term}")
            results = self.engine.search(term)   # 用同一个 engine 实例
            print(f"找到 {len(results)} 条信息")
            all_results.append({"term": term, "results": results})
            time.sleep(2)
        return all_results

    def post(self, shared, prep_res, exec_res):
        shared["context"].extend(exec_res)
        return "search_done"


class FilterTitles(Node):
    """基于 Ollama LLM 对 SearchInfo 拿到的结果按标题做过滤"""
    def __init__(self):
        super().__init__()

    def prep(self, shared: dict):
        """
        输入：
          shared["current_section"]["name"]  —— 本章标题
          shared["context"]（由 SearchInfo.post 放入）——列表格式，每个元素是 {'term': ..., 'results': [...]}
        返回：
          sec_name, flat_items：
            flat_items 是 [{'title': ..., 'url': ...}, ...] 扁平化列表
        """
        themes = shared.get("industry", "行业研究")
        sec_name = shared["current_section"]["name"]
        flat = []
        for block in shared.get("context", []):
            for item in block["results"]:
                flat.append({"title": item["title"], "url": item["url"]})
        return themes, sec_name, flat

    def exec(self, inputs) -> List[Dict]:
        
        # 直接call LLM
        themes, sec_name, flat = inputs
        titles = yaml.dump(flat, allow_unicode=True)
        # 只需要title，然后编号
        titles = "\n".join(f"- {i}. {it['title']}" for i, it in enumerate(flat))

        prompt = FILTER_TITLES_PROMPT.format(
            industry_name=themes,
            section_name=sec_name,
            titles=titles
        )
        # 保存prompt到本地
        # 统计当前章节的过滤次数，用于文件名唯一性
        safe_sec_name = sec_name.replace(' ', '_').replace('/', '_').replace('\\', '_')
        if not hasattr(self, "_filter_count"):
            self._filter_count = {}
        self._filter_count[safe_sec_name] = self._filter_count.get(safe_sec_name, 0) + 1
        prompt_file = f"./macro_outputs/prompts/filter_titles_prompt_{safe_sec_name}_{self._filter_count[safe_sec_name]}.txt"
        
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write(prompt)
        logger.info(f"[FilterTitles] Saved prompt for section '{sec_name}' → {prompt_file}")
        resp_text = call_llm(prompt).strip()
        logger.info(f"[FilterTitles] LLM response: {resp_text}")
        # print(f"LLM 响应：{resp_text}")
        
        # 从 resp_text 中抽取 JSON 数组
        import re, json
        m = re.search(r"\[.*\]", resp_text, re.S)
        try:
            idxs = json.loads(m.group(0)) if m else []
        except Exception:
            idxs = []

        # 根据 idxs 过滤
        filtered = [flat[i] for i in idxs if 0 <= i < len(flat)]
        return filtered

    def post(self, shared, prep_res, exec_res):
        # 过滤后直接覆盖 shared["context"]
        shared["context"] = exec_res
        return None


class GenerateSection(Node):
    """章节生成节点"""
    def __init__(self):
        super().__init__()
        self._count = 0

    def prep(self, shared):
        # 直接从知识库获取当前章节的内容
        section_name = shared["current_section"]["name"]
        context = knowledge_base.get_all_content_for_section(section_name)
        
        return (
            shared["industry"],
            shared["current_section"],
            context,
            shared["focus_areas"]
        )

    def exec(self, inputs):
        self._count += 1
        industry, section, context, focus_areas = inputs
        prompt = GENERATE_SECTION_PROMPT.format(
            industry=industry,
            section_name=section['name'],
            section_focus=section['focus'],
            context_count=len(context),
            context_str=yaml.dump(context, allow_unicode=True)
        )
        
        # 保存prompt到本地
        safe_name = section['name'].replace(' ', '_').replace('/', '_').replace('\\', '_')
        prompt_file = f"./macro_outputs/prompts/generate_section_prompt_{self._count}_{safe_name}.txt"
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write(prompt)
        logger.info(f"[Generate] Saved prompt for section '{section['name']}' → {prompt_file}")
        
        content = call_llm(prompt)
        # 保存到本地
        filename = f"./macro_outputs/sections/section_{self._count}_{safe_name}.md"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"# {section['name']}\n\n")
            f.write(content)
        logger.info(f"[Generate] Saved section '{section['name']}' → {filename}")

        return {"name": section["name"], "content": content}

    def post(self, shared, prep_res, exec_res):
        shared.setdefault("generated_sections", []).append(exec_res)
        return "continue"

class CompleteReport(Node):
    """最终报告整合节点"""
    def prep(self, shared):
        return shared["industry"], shared["generated_sections"]

    def exec(self, inputs):
        industry, sections = inputs
        sections_content = "\n".join(f"## {sec['name']}\n\n{sec['content']}" for sec in sections)
        prompt = COMPLETE_REPORT_PROMPT.format(
            industry=industry,
            sections_content=sections_content
        )
        
        # 保存prompt到本地
        prompt_file = f"./macro_outputs/prompts/complete_report_prompt.txt"
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write(prompt)
        logger.info(f"[CompleteReport] Saved prompt → {prompt_file}")
        
        content = call_llm(prompt)
        return content

    def post(self, shared, prep_res, exec_res):
        shared["final_report"] = exec_res
        return exec_res


class CheckMermaidSyntax(Node):
    """检查和修复报告中的Mermaid语法错误"""
    def prep(self, shared):
        return shared.get("final_report", "")

    def exec(self, report_content):
        if not report_content:
            logger.warning("[CheckMermaid] No report content to check")
            return report_content
            
        # 检查是否包含mermaid代码
        if "```mermaid" not in report_content.lower():
            logger.info("[CheckMermaid] No mermaid code found in report")
            return report_content
            
        prompt = CHECK_MERMAID_SYNTAX_PROMPT.format(report_content=report_content)
        
        # 保存prompt到本地
        prompt_file = f"./macro_outputs/prompts/check_mermaid_prompt.txt"
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write(prompt)
        logger.info(f"[CheckMermaid] Saved prompt → {prompt_file}")
        
        # 调用LLM检查和修复语法
        corrected_content = call_llm(prompt)
        
        # 保存修复前后的对比
        comparison_file = f"./macro_outputs/mermaid_syntax_check.md"
        with open(comparison_file, 'w', encoding='utf-8') as f:
            f.write("# Mermaid语法检查报告\n\n")
            f.write("## 修复前\n\n")
            f.write(report_content)
            f.write("\n\n## 修复后\n\n")
            f.write(corrected_content)
        logger.info(f"[CheckMermaid] Saved comparison → {comparison_file}")
        
        return corrected_content

    def post(self, shared, prep_res, exec_res):
        # 保存最终修复后的报告
        with open("Macro_Research_Report.md", "w", encoding="utf-8") as f:
            f.write(exec_res)
        print("=== 研报已保存到 'Macro_Research_Report.md' (Mermaid语法已检查修复) ===")
        shared["final_md_path"] = "Macro_Research_Report.md"  # 保存MD文件路径供后续转换使用
        return None


class ConvertToDocx(Node):
    """将Markdown报告转换为Word文档"""
    def prep(self, shared):
        md_path = shared.get("final_md_path", "Macro_Research_Report.md")
        return md_path

    def exec(self, md_path):
        if not os.path.exists(md_path):
            logger.error(f"[ConvertToDocx] Markdown file not found: {md_path}")
            return None
            
        # 生成Word文件路径
        docx_path = md_path.replace('.md', '.docx')
        
        try:
            # 使用md2docx转换，支持Mermaid图表
            convert_md_to_docx_with_mermaid(
                input_md=md_path,
                output_docx=docx_path,
                tmp_dir_parent="./macro_outputs/",
                with_mermaid=True,
                mermaid_backend="web"
            )
            
            logger.info(f"[ConvertToDocx] Successfully converted {md_path} to {docx_path}")
            return docx_path
            
        except Exception as e:
            logger.error(f"[ConvertToDocx] Failed to convert to DOCX: {str(e)}")
            return None

    def post(self, shared, prep_res, exec_res):
        if exec_res:
            shared["final_docx_path"] = exec_res
            print(f"=== Word版研报已生成: '{exec_res}' ===")
        else:
            print("=== Word转换失败，请检查依赖项是否已安装 ===")
        return None

def main(marco_name: str, time_range: str):

    # 初始共享状态
    shared_state = {
        "industry": f"{marco_name} ({time_range})",
        "focus_areas": ["GDP", "CPI", "利率", "汇率"],
    }

    # 1. 规划章节
    planner = PlanSections()
    # 正确调用
    prep_res = planner.prep(shared_state)
    sections = planner.exec(prep_res)
    planner.post(shared_state, prep_res, sections)

    # 打印规划结果
    print("\n=== 规划章节 ===")
    print(f"一共生成了 {len(shared_state['sections_plan'])} 个章节")
    for sec in shared_state["sections_plan"]:
        print(f"- {sec['name']}: {sec['focus']}")

    # 节点实例
    decider = IndustryResearchFlow(max_search_attempts=MAX_SEARCH_ATTEMPTS)
    searcher = SearchInfo()
    generator = GenerateSection()
    completer = CompleteReport()
    mermaid_checker = CheckMermaidSyntax()
    docx_converter = ConvertToDocx()
    filterer = FilterTitles()

    # 2. 针对每个章节，循环决策 → 搜索/生成
    for sec in shared_state["sections_plan"]:
        shared_state["current_section"] = sec
        consecutive_no_new_knowledge = 0  # 连续无新增知识的次数
        max_consecutive_no_new = 2  # 最大连续无新增次数
        
        # —— 新章节开始，清空 cache —— 
        print(f"\n=== 新章节[{sec['name']}]开始，清空搜索缓存 ===")
        searcher.engine.clear_cache()
        
        while True:
            # 决策
            prep_res = decider.prep(shared_state)
            decision = decider.exec(prep_res)
            # 打印决策结果
            print(f"决策：{decision['action']} - {decision['reason']}")
            next_action = decider.post(shared_state, prep_res, decision)

            # if decision["action"] == "search":
            #     # 执行搜索
            #     terms = shared_state["search_terms"]
            #     print("要搜索的关键词：", terms)
            #     search_res = searcher.exec(terms)
            #     searcher.post(shared_state, None, search_res)
            #     continue
            
            if decision["action"] == "search":
                terms = shared_state["search_terms"]
                print("要搜索的关键词：", terms)
                # 1) 搜索
                search_res = searcher.exec(terms)
                searcher.post(shared_state, None, search_res)

                # 2) 过滤标题
                print("要过滤的标题：", shared_state["current_section"]["name"])
                total_results = sum(len(block["results"]) for block in shared_state["context"])
                print("搜索结果数量：", total_results)
                prep_f = filterer.prep(shared_state)
                filtered = filterer.exec(prep_f)
                filterer.post(shared_state, prep_f, filtered)
                print(f"过滤后剩余 {len(filtered)} 条结果")
                print(filtered)

                # 3) 提取url中的内容并保存到本地知识库
                extracted_contents = []
                section_name = shared_state["current_section"]["name"]
                
                # 知识库章节计数
                section_count = knowledge_base.get_section_count(section_name)
                print(f"当前章节 '{section_name}' 的知识库内容数量：{section_count}")
                
                for item in filtered:
                    url = item.get("url")
                    if url:
                        # 先检查本地知识库是否已存在
                        cached_content = knowledge_base.get_content(url)
                        if cached_content:
                            logger.info(f"[KnowledgeBase] Found cached content for {url}")
                            extracted_contents.append(cached_content)
                        else:
                            # 提取新内容并保存
                            logger.info(f"[KnowledgeBase] Extracting new content from {url}")
                            content_data = extract_content_from_url(url)
                            if content_data["status"] == "success":
                                # 保存到知识库，指定章节
                                knowledge_base.save_content(
                                    url, 
                                    content_data["title"], 
                                    content_data["content"],
                                    section_name  # 添加章节信息
                                )
                            extracted_contents.append(content_data)
                            
                # 知识库新增数量
                new_count = knowledge_base.get_section_count(section_name) - section_count
                print(f"章节 '{section_name}' 新增知识数量：{new_count}")
                
                # 如果没有新增知识，检查是否需要跳过决策
                if new_count == 0:
                    consecutive_no_new_knowledge += 1
                    print(f"本轮搜索未新增任何知识，连续无新增次数：{consecutive_no_new_knowledge}")
                    
                    if consecutive_no_new_knowledge < max_consecutive_no_new:
                        print(f"直接进行下一轮搜索（跳过决策）...")
                        logger.info(f"[Search] No new knowledge added for section '{section_name}', skipping decision and continuing search")
                        # 清空上下文并继续下一轮搜索
                        shared_state["context"] = []
                        continue
                    else:
                        print(f"连续{max_consecutive_no_new}次无新增知识，强制进行决策...")
                        logger.info(f"[Search] {max_consecutive_no_new} consecutive searches with no new knowledge, forcing decision")
                        consecutive_no_new_knowledge = 0  # 重置计数器
                else:
                    consecutive_no_new_knowledge = 0  # 有新增知识，重置计数器
                
                # 内容已保存到知识库，清空shared中的context
                # 决策时会从知识库重新加载
                shared_state["context"] = []
                logger.info(f"[KnowledgeBase] Cleared shared context, content saved to knowledge base for section '{section_name}'")

                continue
            
            
            else:
                # 生成章节
                gen = generator.exec(generator.prep(shared_state))
                generator.post(shared_state, None, gen)
                break

    # 3. 整合最终报告
    final_content = completer.exec(completer.prep(shared_state))
    completer.post(shared_state, None, final_content)
    
    # 4. 检查和修复Mermaid语法
    print("\n=== 检查和修复Mermaid语法 ===")
    corrected_content = mermaid_checker.exec(mermaid_checker.prep(shared_state))
    mermaid_checker.post(shared_state, None, corrected_content)
    
    # 5. 转换为Word文档
    print("\n=== 转换为Word文档 ===")
    docx_path = docx_converter.exec(docx_converter.prep(shared_state))
    docx_converter.post(shared_state, None, docx_path)
    return docx_path

if __name__ == "__main__":
    main("国家级“人工智能+”政策效果评估", "2023-2025")