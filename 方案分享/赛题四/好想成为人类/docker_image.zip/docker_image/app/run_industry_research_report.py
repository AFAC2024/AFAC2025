import argparse
import sys
import os

# 添加项目根目录和industry目录到Python路径
project_root = os.path.dirname(os.path.abspath(__file__))
industry_dir = os.path.join(project_root, "industry")
# sys.path.insert(0, project_root)
# sys.path.insert(0, industry_dir)

# 直接导入模块文件
import importlib.util
industry_file_path = os.path.join(industry_dir, "industry_research_report.py")
spec = importlib.util.spec_from_file_location("industry_research_report", industry_file_path)
industry_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(industry_module)

# 获取main函数
main = industry_module.main

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='运行行业研究报告生成工具')
    parser.add_argument('--industry_name', 
                       required=True, 
                       help='研究主题名称，例如：生成式AI基建与算力投资趋势')
    return parser.parse_args()

if __name__ == "__main__":
    # 解析命令行参数
    args = parse_args()
    
    # 调用主函数
    print(f"正在生成研究报告...")
    print(f"主题: {args.industry_name}")
    
    main(args.industry_name)
