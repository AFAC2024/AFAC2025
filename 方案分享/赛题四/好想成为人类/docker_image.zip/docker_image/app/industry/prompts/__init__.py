from pathlib import Path

_module_dir = Path(__file__).absolute().parent


def get_prompt(file_name:str):
    with open(_module_dir / f"{file_name}.md", "r") as fp:
        prompt = fp.read()

    return prompt

DECISION_PROMPT = get_prompt("00_decision")
GENERATE_PROMPT = get_prompt("02_generate")