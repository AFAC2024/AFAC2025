#!/usr/bin/env python3
"""
研究报告生成器主程序
支持公司、行业和宏观经济研究报告生成
"""

import argparse
import sys
import os
import importlib.util
from pathlib import Path
import traceback
import shutil

# def load_module_from_path(module_name, file_path):
#     """动态加载模块"""
#     spec = importlib.util.spec_from_file_location(module_name, file_path)
#     module = importlib.util.module_from_spec(spec)
#     spec.loader.exec_module(module)
#     return module

def run_company_report(company_name, company_code, search_engine='sogou'):
    """运行公司研究报告"""
    try:
        from company.company_research_report_generator import IntegratedResearchReportGenerator
        
        print("=" * 50)
        print(f"🚀 开始为 '{company_name}' 生成研究报告...")
        print(f"   公司代码: {company_code}")
        print(f"   搜索引擎: {search_engine.upper()}")
        print("=" * 50)

        # 解析公司代码和市场
        parts = company_code.split('.')
        if len(parts) != 2:
            print(f"❌ 错误：公司代码格式不正确 '{company_code}'。应为 '代码.市场' 格式，例如 '00020.HK' 或 '600519.SH'。")
            return None

        code, market = parts[0], parts[1].upper()

        # 对A股市场代码进行简单规范化处理
        if market in ['SH', 'SZ']:
            market = 'A'
            print(f"   解析结果 -> 代码: {code}, 市场: {market} (A股)")
        elif market == 'HK':
            print(f"   解析结果 -> 代码: {code}, 市场: {market} (港股)")
        else:
            print(f"⚠️ 警告：无法识别的市场代码 '{market}'，将按原样传递。")

        # 初始化并运行生成器
        generator = IntegratedResearchReportGenerator(
            target_company=company_name,
            target_company_code=code,
            target_company_market=market,
            search_engine=search_engine
        )

        print("🔄 开始运行完整的研报生成流程...")
        result = generator.run_full_pipeline() # docx 目录

        if result:
            print(f"✅ 研报生成成功！输出文件：{result}")
            return result
        else:
            print("❌ 研报生成失败。")
            return None

    except Exception as e:
        import traceback
        print(f"❌ 公式报告生成失败：{e}")
        print("详细错误信息：")
        traceback.print_exc()
        return None

def run_industry_report(industry_name, time_range=None):
    """运行行业研究报告"""
    try:
        # 动态导入行业报告模块
        from industry.industry_research_report import main as industry_main
        # industry_file_path = "industry/industry_research_report.py"
        # industry_module = load_module_from_path("industry_research_report", industry_file_path)
        
        print(f"正在生成行业研究报告...")
        print(f"行业名称: {industry_name}")
        # print(f"时间范围: {time_range}")
        
        docx_path = industry_main(industry_name, time_range) # docx_path
        return docx_path
    except Exception as e:
        print(f"❌ 行业报告生成失败：{e}")
        print("详细错误信息：")
        traceback.print_exc()
        return None

def run_macro_report(macro_name, time_range):
    """运行宏观经济研究报告"""
    try:
        # 动态导入宏观报告模块
        from macro.marco_research_report import main as marco_main
        # macro_file_path = "macro/marco_research_report.py.py"
        # macro_module = load_module_from_path("marco_research_report", macro_file_path)
        
        print(f"正在生成宏观研究报告...")
        print(f"主题: {macro_name}")
        print(f"时间范围: {time_range}")
        
        docx_path = marco_main(macro_name, time_range) # docx_path
        return docx_path
    except Exception as e:
        print(f"❌ 宏观报告生成失败：{e}")
        print("详细错误信息：")
        traceback.print_exc()
        return None

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='研究报告生成器')
    subparsers = parser.add_subparsers(dest='command', help='可用的命令')

    # 公司研究报告子命令
    company_parser = subparsers.add_parser('company', help='生成公司研究报告')
    company_parser.add_argument('--company_name', required=True, help='公司名称')
    company_parser.add_argument('--company_code', required=True, help='公司代码（格式：代码.市场，如 00020.HK）')
    company_parser.add_argument('--search_engine', default='sogou', help='搜索引擎（默认：sogou）')

    # 行业研究报告子命令
    industry_parser = subparsers.add_parser('industry', help='生成行业研究报告')
    industry_parser.add_argument('--industry_name', required=True, help='行业名称')
    # industry_parser.add_argument('--time', required=True, help='时间范围')

    # 宏观研究报告子命令
    macro_parser = subparsers.add_parser('macro', help='生成宏观研究报告')
    macro_parser.add_argument('--macro_name', required=True, help='宏观主题名称')
    macro_parser.add_argument('--time', required=True, help='时间范围')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    # 根据命令执行相应的函数
    if args.command == 'company':
        result = run_company_report(args.company_name, args.company_code, args.search_engine)
    elif args.command == 'industry':
        result = run_industry_report(args.industry_name)
    elif args.command == 'macro':
        result = run_macro_report(args.macro_name, args.time)
    else:
        parser.print_help()
        return

    result_path = Path(result)
    out_path = Path("./outputs")
    out_path.mkdir(exist_ok=True)
    if result_path.is_file():
        shutil.copy2(result_path, str(out_path / result_path.name))
        print(f"\n✅ 报告生成完成：{result}")
    else:
        print("\n❌ 报告生成失败")
        sys.exit(1)

if __name__ == "__main__":
    main()
