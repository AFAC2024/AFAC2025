# run_company_research_report.py

import argparse
import os
import sys

# 导入核心的研报生成器类
from company.company_research_report_generator import IntegratedResearchReportGenerator


def run(company_name: str, company_code_full: str, search_engine: str = 'sogou'):
    """
    运行公司研究报告生成流程。

    Args:
        company_name (str): 公司名称, 例如 '商汤科技'.
        company_code_full (str): 完整的公司代码，包含市场后缀, 例如 '00020.HK'.
        search_engine (str, optional): 使用的搜索引擎. 默认为 'sogou'.

    Returns:
        str: 生成的Word文档的路径，如果失败则返回None.
    """
    print("=" * 50)
    print(f"🚀 开始为 '{company_name}' 生成研究报告...")
    print(f"   公司代码: {company_code_full}")
    print(f"   搜索引擎: {search_engine.upper()}")
    print("=" * 50)

    # --- 1. 解析公司代码和市场 ---
    parts = company_code_full.split('.')
    if len(parts) != 2:
        print(f"❌ 错误：公司代码格式不正确 '{company_code_full}'。应为 '代码.市场' 格式，例如 '00020.HK' 或 '600519.SH'。")
        return None

    code, market = parts[0], parts[1].upper()

    # 对A股市场代码进行简单规范化处理
    if market in ['SH', 'SZ']:
        market = 'A'  # 生成器内部逻辑会处理A股市场
        # 生成器内部有逻辑可以自动补全 SH/SZ, 这里保持代码和市场分离即可
        print(f"   解析结果 -> 代码: {code}, 市场: {market} (A股)")
    elif market == 'HK':
        print(f"   解析结果 -> 代码: {code}, 市场: {market} (港股)")
    else:
        print(f"⚠️ 警告：无法识别的市场代码 '{market}'，将按原样传递。")

    try:
        # --- 2. 初始化并运行生成器 ---
        generator = IntegratedResearchReportGenerator(
            target_company=company_name,
            target_company_code=code,
            target_company_market=market,
            search_engine=search_engine
        )

        # 运行完整流程，它会返回 (markdown_path, docx_path)
        _, final_docx_path = generator.run_full_pipeline()

        # --- 3. 确认文件位置 ---
        if final_docx_path and os.path.exists(final_docx_path):
            # 获取项目根目录（即当前脚本所在目录）
            project_root = os.path.dirname(os.path.abspath(__file__))
            # 获取文件的绝对路径
            absolute_docx_path = os.path.abspath(final_docx_path)

            print("\n" + "*" * 60)
            print("🎉🎉🎉 研究报告生成成功! 🎉🎉🎉")
            print(f"✅ Word 文档已生成在项目根目录下。")
            print(f"   文件路径: {absolute_docx_path}")
            print("*" * 60)
            return absolute_docx_path
        else:
            print("\n" + "!" * 60)
            print("❌ 错误：报告生成流程已结束，但未找到最终的 Word 文档。")
            print(f"   预期路径: {final_docx_path}")
            print("!" * 60)
            return None

    except Exception as e:
        import traceback
        print("\n" + "!" * 60)
        print(f"❌ 报告生成过程中发生严重错误: {e}")
        print(traceback.format_exc())
        print("!" * 60)
        return None


def main():
    """
    命令行接口主函数
    """
    parser = argparse.ArgumentParser(
        description="公司研究报告生成器命令行工具。",
        formatter_class=argparse.RawTextHelpFormatter  # 保持帮助信息格式
    )
    parser.add_argument(
        '--company_name',
        required=True,
        type=str,
        help="目标公司的名称。\n示例: --company_name '商汤科技'"
    )
    parser.add_argument(
        '--company_code',
        required=True,
        type=str,
        help="目标公司的完整股票代码，格式为 '代码.市场'。\n市场支持: HK (港股), SH (沪市A股), SZ (深市A股)。\n示例: --company_code '00020.HK'"
    )
    parser.add_argument(
        '--search_engine',
        choices=['ddg', 'sogou'],
        default='sogou',
        help="选择用于信息搜集的搜索引擎。\n'ddg' for DuckDuckGo, 'sogou' for 搜狗。\n(默认: sogou)"
    )

    # 如果没有提供参数，则打印帮助信息
    if len(sys.argv) == 1:
        parser.print_help(sys.stderr)
        sys.exit(1)

    args = parser.parse_args()

    # 调用核心运行函数
    run(args.company_name, args.company_code, args.search_engine)


if __name__ == '__main__':
    main()
