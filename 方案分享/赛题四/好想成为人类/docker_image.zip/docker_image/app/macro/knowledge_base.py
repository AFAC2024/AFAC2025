import os
import json
import hashlib
import logging
import requests
from datetime import datetime
from typing import List, Dict
from bs4 import BeautifulSoup
from .utils.url_handler import resolve_url

# 配置日志
logger = logging.getLogger("knowledge_base")


class KnowledgeBase:
    """本地知识库管理类"""

    def __init__(self, base_dir="./macro_outputs/knowledge_base"):
        self.base_dir = base_dir
        self.metadata_file = os.path.join(base_dir, "metadata.json")
        self._load_metadata()
    
    def _load_metadata(self):
        """加载知识库元数据"""
        if os.path.exists(self.metadata_file):
            with open(self.metadata_file, 'r', encoding='utf-8') as f:
                self.metadata = json.load(f)
        else:
            self.metadata = {}
    
    def _save_metadata(self):
        """保存知识库元数据"""
        with open(self.metadata_file, 'w', encoding='utf-8') as f:
            json.dump(self.metadata, f, ensure_ascii=False, indent=2)
    
    def _url_to_hash(self, url: str) -> str:
        """将URL转换为哈希值作为文件名"""
        return hashlib.md5(url.encode('utf-8')).hexdigest()
    
    def url_exists(self, url: str) -> bool:
        """检查URL是否已经存在于知识库中"""
        url_hash = self._url_to_hash(url)
        return url_hash in self.metadata
    
    def save_content(self, url: str, title: str, content: str, section_name: str = None) -> str:
        """保存URL内容到本地知识库"""
        url_hash = self._url_to_hash(url)
        content_file = os.path.join(self.base_dir, f"{url_hash}.txt")
        
        # 保存内容
        with open(content_file, 'w', encoding='utf-8') as f:
            f.write(content)
        
        # 更新元数据
        self.metadata[url_hash] = {
            "url": url,
            "title": title,
            "content_file": content_file,
            "timestamp": datetime.now().isoformat(),
            "content_length": len(content),
            "section_name": section_name  # 记录所属章节
        }
        self._save_metadata()
        
        # 如果指定了章节，也保存到章节目录
        if section_name:
            self._save_to_section(url_hash, section_name)
        
        logger.info(f"[KnowledgeBase] Saved content from {url} → {content_file}")
        return content_file
    
    def _save_to_section(self, url_hash: str, section_name: str):
        """将内容索引保存到章节目录"""
        section_dir = os.path.join(self.base_dir, "sections", section_name.replace(' ', '_').replace('/', '_').replace('\\', '_'))
        os.makedirs(section_dir, exist_ok=True)
        
        section_file = os.path.join(section_dir, f"{url_hash}.json")
        with open(section_file, 'w', encoding='utf-8') as f:
            json.dump(self.metadata[url_hash], f, ensure_ascii=False, indent=2)
    
    # 获取当前章节知识库的知识num
    def get_section_count(self, section_name: str) -> int:
        """获取某个章节的知识数量"""
        section_dir = os.path.join(self.base_dir, "sections", section_name.replace(' ', '_').replace('/', '_').replace('\\', '_'))
        if not os.path.exists(section_dir):
            return 0
        
        count = 0
        for filename in os.listdir(section_dir):
            if filename.endswith('.json'):
                count += 1
        return count
    
    def get_content(self, url: str) -> dict:
        """从本地知识库获取URL内容"""
        url_hash = self._url_to_hash(url)
        if url_hash not in self.metadata:
            return None
        
        metadata = self.metadata[url_hash]
        content_file = metadata["content_file"]
        
        if os.path.exists(content_file):
            with open(content_file, 'r', encoding='utf-8') as f:
                content = f.read()
            return {
                "url": metadata["url"],
                "title": metadata["title"],
                "content": content,
                "timestamp": metadata["timestamp"]
            }
        return None
    
    def get_all_content_for_section(self, section_name: str) -> List[dict]:
        """获取某个章节的所有相关内容"""
        section_dir = os.path.join(self.base_dir, "sections", section_name.replace(' ', '_').replace('/', '_').replace('\\', '_'))
        if not os.path.exists(section_dir):
            return []
        
        results = []
        for filename in os.listdir(section_dir):
            if filename.endswith('.json'):
                with open(os.path.join(section_dir, filename), 'r', encoding='utf-8') as f:
                    metadata = json.load(f)
                    # 读取实际内容
                    content_file = metadata["content_file"]
                    if os.path.exists(content_file):
                        with open(content_file, 'r', encoding='utf-8') as cf:
                            content = cf.read()
                        results.append({
                            "url": metadata["url"],
                            "title": metadata["title"],
                            "content": content,
                            "timestamp": metadata["timestamp"]
                        })
        return results
    
    def remove_content_by_url(self, url: str, section_name: str = None) -> bool:
        """根据URL从知识库中删除内容"""
        try:
            url_hash = self._url_to_hash(url)
            
            # 检查是否存在
            if url_hash not in self.metadata:
                logger.warning(f"[KnowledgeBase] URL not found in metadata: {url}")
                return False
            
            metadata = self.metadata[url_hash]
            content_file = metadata["content_file"]
            
            # 删除内容文件
            if os.path.exists(content_file):
                os.remove(content_file)
                logger.info(f"[KnowledgeBase] Removed content file: {content_file}")
            
            # 从元数据中删除
            del self.metadata[url_hash]
            self._save_metadata()
            
            # 如果指定了章节，也从章节目录中删除
            if section_name:
                self._remove_from_section(url_hash, section_name)
            else:
                # 如果没有指定章节，尝试从所有章节中删除
                sections_dir = os.path.join(self.base_dir, "sections")
                if os.path.exists(sections_dir):
                    for section_folder in os.listdir(sections_dir):
                        self._remove_from_section(url_hash, section_folder)
            
            logger.info(f"[KnowledgeBase] Successfully removed content for URL: {url}")
            return True
            
        except Exception as e:
            logger.error(f"[KnowledgeBase] Failed to remove content for URL {url}: {e}")
            return False
    
    def _remove_from_section(self, url_hash: str, section_name: str):
        """从章节目录中删除内容索引"""
        try:
            section_dir = os.path.join(self.base_dir, "sections", section_name.replace(' ', '_').replace('/', '_').replace('\\', '_'))
            section_file = os.path.join(section_dir, f"{url_hash}.json")
            
            if os.path.exists(section_file):
                os.remove(section_file)
                logger.info(f"[KnowledgeBase] Removed section index: {section_file}")
        except Exception as e:
            logger.warning(f"[KnowledgeBase] Failed to remove section index for {url_hash} in {section_name}: {e}")
    
    def remove_multiple_urls(self, urls: List[str], section_name: str = None, reason: str = "") -> dict:
        """批量删除多个URL的内容"""
        results = {
            "success": [],
            "failed": [],
            "total": len(urls)
        }
        
        if urls:
            logger.info(f"[KnowledgeBase] Starting batch removal of {len(urls)} URLs. Reason: {reason}")
        
        for url in urls:
            if self.remove_content_by_url(url, section_name):
                results["success"].append(url)
            else:
                results["failed"].append(url)
        
        logger.info(f"[KnowledgeBase] Batch removal completed. Success: {len(results['success'])}, Failed: {len(results['failed'])}")
        return results


def extract_content_from_url(url: str, max_length: int = 5000) -> dict:
    """从URL提取内容，自动处理各种重定向链接"""
    original_url = url
    try:
        # 使用URL处理工具解析重定向
        resolved_url = resolve_url(url)
        if resolved_url != url:
            logger.info(f"URL重定向解析: {url[:50]}... -> {resolved_url[:50]}...")
            url = resolved_url
        
        # 清理URL中的异常字符
        url = url.strip("'\"")
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # 移除脚本和样式元素
        for script in soup(["script", "style"]):
            script.decompose()
        
        # 提取标题
        title = soup.find('title')
        title = title.get_text().strip() if title else "无标题"
        
        # 提取正文内容
        # 优先查找常见的内容标签
        content_selectors = [
            'article', '.content', '.main-content', '.post-content', 
            '.article-content', '#content', 'main', '.entry-content'
        ]
        
        content = ""
        for selector in content_selectors:
            elements = soup.select(selector)
            if elements:
                content = ' '.join([elem.get_text().strip() for elem in elements])
                break
        
        # 如果没有找到特定内容区域，提取body内容
        if not content:
            body = soup.find('body')
            if body:
                content = body.get_text()
        
        # 清理内容
        content = ' '.join(content.split())  # 去除多余空白
        content = content[:max_length] if len(content) > max_length else content
        
        return {
            "url": url,
            "title": title,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "status": "success"
        }
        
    except Exception as e:
        logger.error(f"Failed to extract content from {url}: {e}")
        print(f"    - 🚨 提取内容失败: {e}")
        # 提取失败时返回错误信息
        return {
            "url": url,
            "title": "提取失败",
            "content": f"无法提取内容: {str(e)}",
            "timestamp": datetime.now().isoformat(),
            "status": "error"
        }


def main():
    """测试函数"""
    # 配置日志
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # 测试URL
    test_url = "https://www.zhinengxiehui.com/ai/39180.html"
    
    print("=" * 80)
    print("测试 extract_content_from_url 函数")
    print("=" * 80)
    print(f"测试URL: {test_url}")
    print("-" * 80)
    
    # 调用函数
    result = extract_content_from_url(test_url)
    
    # 打印结果
    print(f"状态: {result['status']}")
    print(f"URL: {result['url']}")
    print(f"标题: '{result['title']}'")
    print(f"时间戳: {result['timestamp']}")
    print(f"内容长度: {len(result['content'])}")
    print("-" * 80)
    # print("内容预览 (前500字符):")
    # print(result['content'][:500])
    # if len(result['content']) > 500:
    #     print("...")
    print(result['content'])
    print("=" * 80)
    
    # 测试知识库保存
    print("\n测试知识库保存功能:")
    kb = KnowledgeBase()
    
    if result['status'] == 'success':
        content_file = kb.save_content(
            url=result['url'],
            title=result['title'] if result['title'] else "测试文章",
            content=result['content'],
            section_name="测试章节"
        )
        print(f"✅ 内容已保存到: {content_file}")
        
        # 测试获取内容
        retrieved = kb.get_content(result['url'])
        if retrieved:
            print(f"✅ 内容检索成功，标题: '{retrieved['title']}'")
            print(f"   内容长度: {len(retrieved['content'])}")
        else:
            print("❌ 内容检索失败")
            
        # 测试章节统计
        section_count = kb.get_section_count("测试章节")
        print(f"✅ 章节'测试章节'的内容数量: {section_count}")
        
        # 测试获取章节所有内容
        section_contents = kb.get_all_content_for_section("测试章节")
        print(f"✅ 获取到章节内容数量: {len(section_contents)}")
        
        # 测试URL存在性检查
        exists = kb.url_exists(result['url'])
        print(f"✅ URL存在性检查: {exists}")
        
    else:
        print("❌ 由于提取失败，跳过保存测试")
    
    print("\n" + "=" * 80)
    print("测试完成！")
    print("=" * 80)


def test_single_url(url: str):
    """快速测试单个URL的内容提取"""
    print(f"🔍 测试URL: {url}")
    print("-" * 50)
    
    result = extract_content_from_url(url)
    
    if result['status'] == 'success':
        print("✅ 提取成功!")
        print(f"   标题: {result['title'] or '(无标题)'}")
        print(f"   内容长度: {len(result['content'])} 字符")
        print(f"   内容预览: {result['content'][:100]}...")
    else:
        print("❌ 提取失败!")
        print(f"   错误信息: {result['content']}")
    
    return result


if __name__ == "__main__":
    main()


