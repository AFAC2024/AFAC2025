import argparse
import sys
import os

# 添加项目根目录和macro目录到Python路径
project_root = os.path.dirname(os.path.abspath(__file__))
macro_dir = os.path.join(project_root, "macro")
sys.path.insert(0, project_root)
sys.path.insert(0, macro_dir)

# 直接导入模块文件
import importlib.util
marco_file_path = os.path.join(macro_dir, "marco_research_report.py.py")
spec = importlib.util.spec_from_file_location("marco_research_report", marco_file_path)
marco_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(marco_module)

# 获取main函数
main = marco_module.main

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='运行宏观研究报告生成工具')
    parser.add_argument('--marco_name',
                       required=True,
                       help='宏观研究主题名称，例如：生成式AI基建与算力投资趋势')
    parser.add_argument('--time',
                       required=True,
                       help='时间范围，例如：2023-2026')
    return parser.parse_args()

if __name__ == "__main__":
    # 解析命令行参数
    args = parse_args()

    # 调用主函数
    print(f"正在生成宏观研究报告...")
    print(f"研究主题: {args.marco_name}")
    print(f"时间范围: {args.time}")

    main(args.marco_name, args.time)
