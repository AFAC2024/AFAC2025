# 预估推理时间

推理时间：约10分钟

# 推理资源

使用火山引擎的web api, 推理模型为`deepseek-v3-250324`.

# 算法描述

构建 `MainDecision`, `SearchInfo`, `GenerateSection`, `CompleteReport` 四个节点，分别负责：决策下一步操作，爬取指定网络信息，生成单章报告，整合输出最终报告。其中，`MainDecision`, `GenerateSection`均为基于不同上下文和Prompt的智能体。

各个节点之间的运转逻辑和算法流程如下图所示：

```mermaid
flowchart TD
    A(行业名称) --> |输入| B[MainDecision]
    B --> |决策：search| C[SearchInfo] 
    C --> |返回| B
    B --> |决策：generate| D[GenerateSection] 
    D --> |返回| B
    B --> |决策：complete| E[CompleteReport] 
    E --> |输出| F(最终研报)
```

# 参数设置

temperature = 0.7

其余参数均为openai接口的默认设置。

# 算法迭代过程

baseline：仅包含两个节点，爬虫工具节点`SearchInfo`和撰写报告智能体节点`GenerateReport`，当智能体判断信息不足时自动调用爬虫工具进行补充；

第一次迭代：直接完成完整的报告可能上下文过长，更容易出现幻觉，因此改为`GenerateSection`节点，每次仅生成一个章节，再通过`CompleteReport`节点整理输出完整报告；

第二次迭代：`GenerateSection`节点需要兼顾爬虫工具调用和章节内容生成，输出格式较为混乱，因此独立设置一个决策节点`MainDecision`，此后`GenerateSection`节点仅负责根据给定内容生成文本；同时将节点之间传递的信息固定为yaml格式，便于格式化报告文本和工具调用；

第三次迭代：在`GenerateSection`节点中的智能体prompt中，添加了mermaid代码的模板，并在`CompleteReport`节点中添加了将mermaid转化为对应图表的功能，使生成的报告内容更加丰富。

# Get started

1. 安装了docker之后在本目录下执行以下代码
    ```bash
    docker build -t <镜像名称>:<镜像版本号> .  # 构建镜像
    docker run -it --name <容器名称> <镜像名称>:<镜像版本号>  # 启动容器
    ```
2. 进入容器后执行以下脚本：
    ```bash
    ./run.sh
    ```
    或是自定义参数直接调用python脚本：
    ```bash
    python3 run_industry_research_report.py \
        --industry_name <行业名称> \
        --output_dir <临时文件的输出目录> \
        --max_decide <最大迭代次数>
    ```
3. 执行完毕后会在当前目录下生成`<行业名称>_行业研报.docx`
