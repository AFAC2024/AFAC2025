# -*- coding: utf-8 -*-
"""
配置模块
"""

from .llm_config import LLMConfig

__all__ = ['LLMConfig']
