# 需要先配置好.env文件
python run_industry_research_report.py --industry_name 中国智能服务机器人产业